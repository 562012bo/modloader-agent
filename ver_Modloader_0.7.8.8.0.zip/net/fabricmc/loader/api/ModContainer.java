package net.fabricmc.loader.api;

import java.nio.file.Path;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

import net.fabricmc.loader.api.metadata.ModMetadata;
import net.fabricmc.loader.api.metadata.ModOrigin;

/**
 * Minimal drop-in replacement for real fabric-loader's {@code ModContainer}. Wraps this
 * modloader's own internal {@code ankhangbo.modloader.internal.ModContainer} (see
 * {@code ankhangbo.modloader.compat.fabricloader.ModContainerImpl}) — {@link #getMetadata()} and
 * {@link #getRootPaths()}/{@link #getOrigin()} are what ported mods call most often, so those are
 * the ones actually backed by real data. There is no equivalent of Fabric's nested-jar / origin
 * chain here (mods are always exactly one flat jar in {@code mods/}), so {@link #getOrigin()}
 * always reports a single {@link ModOrigin} of kind {@code PATH} pointing at that one jar.
 *
 * <p><b>{@link #getOrigin()} must return the real, top-level
 * {@code net.fabricmc.loader.api.metadata.ModOrigin}</b> — not a locally-declared nested type of
 * the same simple name. A real, precompiled mod jar (e.g. e4mc) is linked against real
 * fabric-loader's actual {@code ModOrigin} class; returning any other type, even one with an
 * identical shape, throws {@code NoSuchMethodError} the moment it calls {@code getOrigin()},
 * because the method's descriptor (which bakes in the fully-qualified return type) no longer
 * matches what the mod's bytecode expects.
 *
 * <p><b>THIS INTERFACE MUST STAY IN SYNC WITH REAL FABRIC LOADER'S {@code ModContainer}</b> — any
 * caller compiled against the real fabric-loader-api jar (a real mod, OR, as it turns out,
 * <i>Paper itself</i> — {@code net.minecraft.SystemReport} calls {@code getContainingMod()} when
 * building a crash report's mod list) bakes the FULL method set it expects directly into its own
 * bytecode at compile time. Missing even one method here throws {@code NoSuchMethodError} the
 * moment that specific method gets called — NOT a compile error, and not even necessarily at
 * class-load time; it can surface arbitrarily later; only when a call to that missing method
 * actually happens (which is exactly how the {@code getContainingMod()} crash was found — it
 * only fires during {@code CrashReport}/{@code SystemReport} construction). If you see
 * {@code NoSuchMethodError} pointing at a method name on this interface, add it here, matching
 * real fabric-loader's exact signature, and implement it in every implementor below.
 */
public interface ModContainer {
	ModMetadata getMetadata();

	List<Path> getRootPaths();

	/**
	 * Real fabric-loader convenience method — {@code default Path getRootPath() { return
	 * getRootPaths().get(0); }}. Older/simpler mods (confirmed: dynmap's
	 * {@code DynmapMod.onInitialize}) call this singular form directly instead of
	 * {@link #getRootPaths()}; missing it throws NoSuchMethodError the moment such a mod's
	 * entrypoint runs. Default method — every existing implementor gets this for free.
	 */
	default Path getRootPath() {
		return getRootPaths().get(0);
	}

	Optional<Path> findPath(String path);

	ModOrigin getOrigin();

	/**
	 * Real fabric-loader: for a jar-in-jar nested mod, the mod that embedded it; empty for a
	 * normal top-level mod. This modloader has no jar-in-jar nesting concept for
	 * {@code mods.json}-based mods (always one flat jar), so this always returns
	 * {@link Optional#empty()} UNLESS the specific implementor is itself a nested mod (see
	 * {@code FabricJarModContainerImpl}, which real fabric-jar-in-jar mods DO use).
	 */
	Optional<ModContainer> getContainingMod();

	/**
	 * Real fabric-loader: mods jar-in-jar-embedded INSIDE this one. This modloader has no
	 * jar-in-jar nesting concept for {@code mods.json}-based mods, so this always returns an
	 * empty collection for them; real Fabric-jar mods with a {@code "jars"} array in their
	 * {@code fabric.mod.json} report their extracted nested mods here (see
	 * {@code FabricJarModContainerImpl}).
	 */
	Collection<ModContainer> getContainedMods();

	// --- Real fabric-loader's "deprecated methods" group — kept for old/simple mods that still
	// call these directly instead of the newer findPath()/getRootPaths() forms. Both added as
	// default methods (backed by the newer forms above) so every implementor gets them for free,
	// matching this interface's own stated policy in the class javadoc above: "If you see
	// NoSuchMethodError pointing at a method name on this interface, add it here."

	/**
	 * Real fabric-loader: {@code @Deprecated Path getPath(String file)} — nullable-returning
	 * sibling of {@link #findPath(String)}'s {@code Optional<Path>}. Confirmed missing: LuckPerms'
	 * {@code LPFabricBootstrap.getResourceStream} calls this directly during config resolution.
	 */
	default Path getPath(String file) {
		return findPath(file).orElse(null);
	}

	/**
	 * Real fabric-loader: {@code @Deprecated Path getRoot()} — singular alias of
	 * {@link #getRootPath()} (itself already an alias of {@link #getRootPaths()}'s first entry).
	 * Added preemptively alongside {@link #getPath(String)} since it's the other still-missing
	 * entry in real fabric-loader's same "deprecated methods" group — an old mod calling one of
	 * these two is quite likely to also call the other.
	 */
	default Path getRoot() {
		return getRootPath();
	}
}
