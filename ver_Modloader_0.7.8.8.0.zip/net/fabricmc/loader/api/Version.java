package net.fabricmc.loader.api;

/**
 * Minimal drop-in replacement for real fabric-loader's {@code Version} interface. Only
 * {@link #getFriendlyString()} is guaranteed meaningful here — this modloader does not implement
 * semver comparison/range matching (real fabric-loader's {@code SemanticVersion}), since nothing
 * in this codebase resolves dependency version ranges today. If a ported mod calls
 * {@code compareTo} on this, it falls back to plain string comparison.
 */
public interface Version extends Comparable<Version> {
	String getFriendlyString();

	static Version parse(String raw) {
		return new ankhangbo.modloader.compat.fabricloader.SimpleVersion(raw);
	}
}
