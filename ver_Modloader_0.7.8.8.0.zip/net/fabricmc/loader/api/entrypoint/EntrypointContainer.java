package net.fabricmc.loader.api.entrypoint;

import net.fabricmc.loader.api.ModContainer;

/**
 * Copied from real fabric-loader 0.19.3. See
 * {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl#getEntrypointContainers} for the
 * implementation backing this on THIS modloader (fabric-jar mods only — mods.json mods don't have
 * a keyed-entrypoint concept, so they never show up here).
 *
 * @param <T> The type of the entrypoint
 * @see net.fabricmc.loader.api.FabricLoader#getEntrypointContainers(String, Class)
 */
public interface EntrypointContainer<T> {
	/** Returns the entrypoint instance. Constructed fresh on the call that first needs it — see
	 *  the implementation's javadoc for why this differs slightly from real fabric-loader's
	 *  "constructed once, cached forever" behavior. */
	T getEntrypoint();

	/** Returns the mod that provided this entrypoint. */
	ModContainer getProvider();

	/** Returns a string representation of the entrypoint's definition. */
	default String getDefinition() {
		return "";
	}
}
