package net.fabricmc.loader.api.entrypoint;

/**
 * An entrypoint invoked at the {@code "preLaunch"} key — very early, BEFORE {@code "main"}/
 * {@code "client"}/{@code "server"}, on BOTH environments regardless of a mod's declared
 * {@code environment} — but AFTER the Mixin environment is fully set up (mods like ModernFix use
 * this phase to do bytecode transforms before the game itself starts initializing).
 *
 * <p>Fired synchronously from {@code ankhangbo.modloader.fabricjar.FabricModLoader.discoverAndLoad}
 * itself (NOT deferred to {@code invokeEntrypoints()} like main/client/server) — see that class'
 * javadoc for exactly why the two phases are split.
 */
public interface PreLaunchEntrypoint {
	void onPreLaunch();
}
