package net.fabricmc.loader.api;

import java.nio.file.Path;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.function.Consumer;

import net.fabricmc.api.EnvType;
import net.fabricmc.loader.api.entrypoint.EntrypointContainer;

/**
 * Drop-in replacement for real fabric-loader's {@code FabricLoader} class, so ported Fabric mod
 * source that does {@code FabricLoader.getInstance().isModLoaded(...)} etc. compiles and works
 * against this modloader instead of needing the real thing on the classpath.
 *
 * <p><b>What's actually backed by real data:</b> {@link #isModLoaded}, {@link #getModContainer},
 * {@link #getAllMods}, {@link #getEntrypointContainers} (fabric-jar mods only — see
 * {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl}'s javadoc on that method),
 * {@link #invokeEntrypoints} (built directly on top of {@link #getEntrypointContainers} — see the
 * implementation's javadoc; added because real, precompiled mod jars (e.g. PacketEvents) call
 * this directly and its absence was a {@code NoSuchMethodError} generator:
 * {@code 'void net.fabricmc.loader.api.FabricLoader.invokeEntrypoints(String, Class, Consumer)'}),
 * {@link #getEnvironmentType} (always {@link EnvType#SERVER} — this modloader is server-only),
 * {@link #isDevelopmentEnvironment} (system property {@code modloader.development}),
 * {@link #getGameDir}/{@link #getConfigDir}.
 *
 * <p><b>What's NOT implemented</b> (throws {@link UnsupportedOperationException} if called):
 * {@code getEntrypoints} (the one remaining entrypoint-related method real fabric-loader has that
 * this doesn't cover), the object share, access widener exposure, and mapping resolver — none of
 * this modloader's ported fabric-api code needs them, and most simple mods don't either. If a mod
 * you're porting needs one of these, it's usually easiest to grep the real fabric-loader source
 * for the method and reimplement just that method here against
 * {@code ankhangbo.modloader.internal.ModManager}.
 *
 * <p><b>Update (v2):</b> {@link #getInstance()} returns
 * {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl.INSTANCE} directly again (the
 * original, simplest form) — that class now EXTENDS {@code net.fabricmc.loader.impl.FabricLoaderImpl}
 * instead of the earlier delegation-based design, so its instance is unconditionally assignable to
 * that internal class regardless of build/classloading quirks. See
 * {@code net.fabricmc.loader.impl.FabricLoaderImpl}'s javadoc for the full "why" (some real mod
 * jars {@code checkcast} down to that exact internal class — found via {@code javap} on a real
 * mod jar).
 */
public interface FabricLoader {
	static FabricLoader getInstance() {
		return ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl.INSTANCE;
	}

	boolean isModLoaded(String id);

	Optional<ModContainer> getModContainer(String id);

	Collection<ModContainer> getAllMods();

	/** See {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl#getEntrypointContainers}
	 *  for exactly what this covers (fabric-jar mods only, fresh instance per call — not a
	 *  byte-for-byte match of real fabric-loader's caching behavior). */
	<T> List<EntrypointContainer<T>> getEntrypointContainers(String key, Class<T> type);

	/** See {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl#invokeEntrypoints} —
	 *  calls {@code invoker} once per entrypoint returned by {@link #getEntrypointContainers},
	 *  isolating each call so one entrypoint's exception doesn't stop the rest from running. */
	<T> void invokeEntrypoints(String key, Class<T> type, Consumer<? super T> invoker);

	EnvType getEnvironmentType();

	boolean isDevelopmentEnvironment();

	Path getGameDir();

	Path getConfigDir();

	/** {@code File} sibling of {@link #getGameDir()} — real fabric-loader has both forms. */
	default java.io.File getGameDirectory() {
		return getGameDir().toFile();
	}

	/** {@code File} sibling of {@link #getConfigDir()} — real fabric-loader has both forms. */
	default java.io.File getConfigDirectory() {
		return getConfigDir().toFile();
	}

	/** Backed by {@code ankhangbo.modloader.fabricjar.GameVersionResolver} — the same mechanism
	 *  already used to check mods' {@code depends: {"minecraft": "..."}} entries. */
	default String getRawGameVersion() {
		String version = ankhangbo.modloader.fabricjar.GameVersionResolver.resolve();
		return version != null ? version : "unknown";
	}

	/**
	 * NOT IMPLEMENTED — real fabric-loader returns the launch process' raw args (sanitized or
	 * not). This modloader has no equivalent captured anywhere yet. Returns an empty array
	 * (a mod checking {@code args.length} sees 0, rather than crashing outright) instead of
	 * throwing, since most mods that call this just scan for a flag and handle "not present"
	 * gracefully on their own.
	 */
	default String[] getLaunchArguments(boolean sanitize) {
		return new String[0];
	}

	/**
	 * NOT IMPLEMENTED. Real fabric-loader returns the running Minecraft server/client instance.
	 * Throws clearly instead of guessing at a wrong object to return — if a mod needs this, wire
	 * it to whatever this project's own bootstrap already holds a reference to (likely
	 * {@code ankhangbo.modloader.ModLoaderHooks} or {@code ModLoaderCore}) rather than guessing here.
	 */
	default Object getGameInstance() {
		throw new UnsupportedOperationException("FabricLoader.getGameInstance() is not implemented "
				+ "by this modloader yet — see this interface's javadoc for how to wire it up");
	}

	/**
	 * NOT IMPLEMENTED — see this interface's class javadoc ("What's NOT implemented").
	 */
	default <T> List<T> getEntrypoints(String key, Class<T> type) {
		throw new UnsupportedOperationException("FabricLoader.getEntrypoints(String, Class) is not "
				+ "implemented by this modloader — use getEntrypointContainers(...) or "
				+ "invokeEntrypoints(...) instead, both of which ARE implemented");
	}
}