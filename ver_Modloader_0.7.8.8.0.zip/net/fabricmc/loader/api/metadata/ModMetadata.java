package net.fabricmc.loader.api.metadata;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import net.fabricmc.loader.api.Version;

/**
 * Minimal drop-in replacement for real fabric-loader's {@code ModMetadata} — covers the handful of
 * getters ported mods actually tend to call ({@code getId}, {@code getVersion}, {@code getName},
 * {@code getDescription}, {@code getAuthors}). Backed by this modloader's own {@code mods.json}
 * (see {@code ankhangbo.modloader.internal.ModDescriptor}), NOT real fabric.mod.json — so fields
 * with no equivalent here (license, icon, custom values, entrypoints, jars, mixins, environment,
 * schemaVersion...) simply aren't exposed. Extend this interface (and its impl,
 * {@code ankhangbo.modloader.compat.fabricloader.ModMetadataImpl}) if a ported mod needs more.
 */
public interface ModMetadata {
	String getId();

	Collection<String> getProvides();

	/**
	 * See {@code ModDependency}'s javadoc — version matching is always permissive since this
	 * modloader doesn't track structured version predicates, only raw depend-string lists.
	 * Added because real, precompiled Fabric mod jars call this via {@code invokeinterface} at
	 * runtime (e.g. littleintermediaryfallback's own dependency-graph building) — a
	 * {@code ModMetadata} implementation missing it throws {@code NoSuchMethodError} even though
	 * this interface's name/package matches real fabric-loader's exactly.
	 */
	Collection<ModDependency> getDependencies();

	Version getVersion();

	String getType();

	String getName();

	String getDescription();

	Collection<Person> getAuthors();

	Collection<Person> getContributors();

	String getContact();

	Collection<String> getLicense();

	/**
	 * Returns if the mod's {@code fabric.mod.json} declares a custom value under {@code key}.
	 * Added because real, precompiled Fabric mod jars (e.g. C2ME's own
	 * {@code ConfigSystem$ConfigAccessor}) call this via {@code invokeinterface} at runtime — a
	 * {@code ModMetadata} implementation missing it throws {@code NoSuchMethodError} even though
	 * this interface's name/package matches real fabric-loader's exactly.
	 */
	boolean containsCustomValue(String key);

	/**
	 * Returns the mod's {@code fabric.mod.json} declared custom value under {@code key}, or
	 * {@code null} if none is present. Only backed by real data for real fabric.mod.json-based
	 * mods (see {@code ankhangbo.modloader.compat.fabricloader.FabricJarModMetadataImpl}) — this
	 * modloader's own {@code mods.json} format has no equivalent concept, so
	 * {@code ankhangbo.modloader.compat.fabricloader.ModMetadataImpl} always returns {@code null}.
	 */
	CustomValue getCustomValue(String key);

	/** Gets all custom values defined by this mod. Empty (not null) if there are none. */
	Map<String, CustomValue> getCustomValues();

	interface Person {
		String getName();
	}

	static List<String> emptyList() {
		return List.of();
	}
}
