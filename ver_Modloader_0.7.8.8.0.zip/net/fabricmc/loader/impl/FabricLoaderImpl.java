package net.fabricmc.loader.impl;

import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.impl.game.GameProvider;


/**
 * Shadow of real fabric-loader's INTERNAL {@code net.fabricmc.loader.impl.FabricLoaderImpl} class.
 * Exists ONLY so mods that {@code checkcast} the result of
 * {@code net.fabricmc.loader.api.FabricLoader.getInstance()} down to this exact class name (an
 * implementation detail some mods/libraries rely on — see below) get a successful cast instead of
 * {@code NoClassDefFoundError}/{@code ClassCastException}.
 *
 * <p><b>Design note (v2 — inheritance, not composition):</b> the first version of this fix made
 * this a separate concrete singleton that DELEGATED to
 * {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl}, with
 * {@code net.fabricmc.loader.api.FabricLoader.getInstance()} returning THIS class's instance. That
 * is fragile: if {@code getInstance()}'s compiled bytecode ever goes stale/out of sync with this
 * file (e.g. an incremental-build artifact problem), you're back to a {@code ClassCastException}
 * because the two classes have no type relationship. Making
 * {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl} EXTEND this class instead means
 * its singleton is unconditionally {@code instanceof net.fabricmc.loader.impl.FabricLoaderImpl}
 * no matter which of the two {@code getInstance()} happens to return — removes that whole failure
 * mode. {@code net.fabricmc.loader.api.FabricLoader.getInstance()} now goes back to returning
 * {@code ankhangbo.modloader.compat.fabricloader.FabricLoaderImpl.INSTANCE} directly (the original,
 * simplest form) — see that file.
 *
 * <p>Confirmed via {@code javap -p -c} on a real mod jar (veinminer-fabric-2.10.3.jar) that this
 * exact checkcast + {@code getGameProvider()} + {@code getRawGameVersion()} chain is what some real
 * mods (usually via a multi-loader abstraction library) actually call. If another mod's bytecode
 * reaches for a DIFFERENT internal method this way, add it here too — find the exact signature with
 * {@code javap -p -c -classpath the-mod.jar <ClassName>} on the mod, same as how this was found.
 */
public abstract class FabricLoaderImpl implements FabricLoader {
	
	public static final String VERSION = "0.19.3";

    public GameProvider getGameProvider() {
        return new ankhangbo.modloader.compat.fabricloader.MinecraftGameProvider();
    }

    public GameProvider tryGetGameProvider() {
        return getGameProvider();
    }
}
