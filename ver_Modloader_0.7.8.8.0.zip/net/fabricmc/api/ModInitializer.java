package net.fabricmc.api;

/**
 * Compat stub of Fabric Loader's real {@code net.fabricmc.api.ModInitializer} — NOT a copy of
 * Fabric Loader itself, just the one-method marker interface every Fabric mod's main class
 * implements. This exists purely so mod jars written against the real Fabric API (like
 * {@code fabric-lifecycle-events-v1}) compile and load under this modloader without needing the
 * actual Fabric Loader on the classpath.
 *
 * See {@code ankhangbo.modloader.internal.ModManager#loadOne} — a mainClass implementing THIS
 * interface (instead of {@code ankhangbo.modloader.api.IModEntrypoint}) is wrapped in a small
 * adapter and its {@link #onInitialize()} is called at the same point {@code IModEntrypoint
 * #onInitialize(ModAPI)} would be. Everything else Fabric-specific (dependency resolution via
 * fabric.mod.json, the client/server env split, etc.) is NOT replicated — this only covers the
 * "my mainClass implements ModInitializer and has a no-arg onInitialize()" shape.
 */
public interface ModInitializer {
    void onInitialize();
}
