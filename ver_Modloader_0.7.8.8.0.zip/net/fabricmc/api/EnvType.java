/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.api;

/**
 * Drop-in replacement for real fabric-loader's {@code EnvType}, so ported Fabric mod source
 * referencing {@code @Environment(EnvType.CLIENT)} / {@code @Environment(EnvType.SERVER)} still
 * compiles against this modloader. This modloader only ever runs on the dedicated server — the
 * annotation is purely a compile-time marker here (nothing strips CLIENT-only classes/methods at
 * runtime), so mods with real client code still need that code to at least compile as dead code,
 * or to be excluded from the build in some other way. See also {@link Environment}.
 */
public enum EnvType {
	CLIENT,
	SERVER
}
