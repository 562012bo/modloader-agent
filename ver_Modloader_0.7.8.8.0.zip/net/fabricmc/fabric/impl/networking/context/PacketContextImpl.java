/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.networking.context;

import java.util.ArrayList;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.mojang.authlib.GameProfile;
import org.jspecify.annotations.NonNull;
import org.jspecify.annotations.Nullable;

import net.minecraft.core.RegistryAccess;
import net.minecraft.network.Connection;
import net.minecraft.resources.Identifier;
import net.minecraft.server.MinecraftServer;

import net.fabricmc.fabric.api.networking.v1.context.PacketContext;

public final class PacketContextImpl implements PacketContext {
	/**
	 * Loader note: this used to be {@code public static final ScopedValue<PacketContext> VALUE}.
	 * Real {@link java.lang.ScopedValue} is only settable via {@code ScopedValue.where(...).run(
	 * Runnable)} / {@code .call(Callable)}, which requires a lambda/method-reference at every call
	 * site. That's fine for the plain-Java call sites in {@link PacketContext} (see its 6 static
	 * helpers below this class) — but {@code PacketDecoderMixin}/{@code PacketEncoderMixin} used to
	 * set it via {@code @WrapMethod}, wrapping the *entire* {@code decode()}/{@code encode()} body —
	 * something that can't be reproduced by inserting plain instructions into already-compiled
	 * bytecode (it would need a hand-built {@code invokedynamic}/{@code LambdaMetafactory} callsite
	 * capturing a renamed copy of the original method, which isn't something to hand-verify without
	 * a compiler). A thread-local push/pop stack is observably identical for every consumer here,
	 * and is trivial to drive correctly from raw ASM: push once at method entry, pop on every exit
	 * (normal return AND thrown exception) — see {@code NetworkingAsmTransformer2}.
	 */
	private static final ThreadLocal<List<PacketContext>> CONTEXT_STACK = ThreadLocal.withInitial(ArrayList::new);

	/**
	 * Associates a {@code PacketDecoder}/{@code PacketEncoder} pipeline-handler instance with the
	 * {@link PacketContext} that should be pushed while it runs. Replaces the mixin-added
	 * {@code PacketContextSetter#fabric_setPacketContext} — set from
	 * {@code NetworkingHooks.wrapInboundTransitioner}/{@code wrapOutboundTransitioner}
	 * (the {@code ConnectionMixin} replacement), read from {@code NetworkingHooks.onDecodeStart}/
	 * {@code onEncodeStart} (the {@code PacketDecoderMixin}/{@code PacketEncoderMixin} replacement).
	 */
	private static final Map<Object, PacketContext> INSTANCE_CONTEXTS = new ConcurrentHashMap<>();

	public static final Key<MinecraftServer> SERVER_INSTANCE = fabricKey("server_instance");
	public static final Key<RegistryAccess> REGISTRY_ACCESS = fabricKey("registry_access");
	public static final Key<GameProfile> GAME_PROFILE = fabricKey("game_profile");
	public static final Key<@NonNull Connection> CONNECTION = fabricKey("connection");

	private final ReadWriteLock lock = new ReentrantReadWriteLock();
	private final Map<Key<?>, Object> contextMap = new IdentityHashMap<>();

	public PacketContextImpl(Connection connection) {
		this.contextMap.put(CONNECTION, connection);
	}

	/** Pushes a (possibly {@code null}) context onto the current thread's stack. Must be paired with {@link #pop()}. */
	public static void push(@Nullable PacketContext ctx) {
		CONTEXT_STACK.get().add(ctx);
	}

	/** Pops the most recently pushed context off the current thread's stack. Safe to call even if nothing is pushed. */
	public static void pop() {
		List<PacketContext> stack = CONTEXT_STACK.get();
		if (!stack.isEmpty()) {
			stack.remove(stack.size() - 1);
		}
	}

	/** @return whether any context (even an explicit {@code null} one, from runWithoutContext) is currently pushed. */
	public static boolean isBound() {
		return !CONTEXT_STACK.get().isEmpty();
	}

	/** @return the topmost pushed context, or {@code null} if none is pushed (or the topmost one is itself {@code null}). */
	public static @Nullable PacketContext current() {
		List<PacketContext> stack = CONTEXT_STACK.get();
		return stack.isEmpty() ? null : stack.get(stack.size() - 1);
	}

	public static void setInstanceContext(Object pipelineHandler, PacketContext context) {
		INSTANCE_CONTEXTS.put(pipelineHandler, context);
	}

	public static @Nullable PacketContext getInstanceContext(Object pipelineHandler) {
		return INSTANCE_CONTEXTS.get(pipelineHandler);
	}

	@Override
	public @Nullable <T> T get(ReadKey<T> key) {
		this.lock.readLock().lock();

		try {
			//noinspection unchecked,SuspiciousMethodCalls
			return (T) this.contextMap.get(key);
		} finally {
			this.lock.readLock().unlock();
		}
	}

	@Override
	public <T> void set(Key<T> key, T value) {
		this.lock.writeLock().lock();

		if (value == null) {
			this.contextMap.remove(key);
		} else {
			this.contextMap.put(key, value);
		}

		this.lock.writeLock().unlock();
	}

	private static <T> Key<T> fabricKey(String path) {
		return PacketContext.key(Identifier.fromNamespaceAndPath("fabric", path));
	}

	public static final class KeyImpl<T> implements PacketContext.Key<T> {
		private final Identifier key;

		public KeyImpl(Identifier key) {
			this.key = key;
		}

		@Override
		public String toString() {
			return "PacketContext.Key[" + this.key + "]";
		}

		public Identifier key() {
			return this.key;
		}
	}
}
