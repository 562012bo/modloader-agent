package ankhangbo.modloader.asm;

import ankhangbo.modloader.ModLoaderHooks;
import org.objectweb.asm.*;
import org.objectweb.asm.tree.*;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Patches exactly one method, chosen because it's the single choke point every code path that
 * ever freezes the built-in registries has to go through — no matter whether that's Paper's own
 * {@code Bootstrap.bootStrap()} call, this loader's {@code ModLoaderCore#finishVanillaBootstrap},
 * or anything else that ends up calling it later:
 *
 *   net/minecraft/core/registries/BuiltInRegistries#bootStrap(Runnable)
 *     -> inject ModLoaderHooks.onRegistriesPreFreeze() immediately before the INVOKESTATIC call
 *        to BuiltInRegistries.freeze() (the private static method that locks every registry —
 *        see that method's own body: {@code REGISTRY.freeze(); createContents(); runnable.run();
 *        freeze(); validate(REGISTRY);}).
 *
 * WHY HERE AND NOT JUST "call our registration code before Bootstrap.bootStrap()":
 * {@code ModLoaderCore#finishVanillaBootstrap} already tries to order things that way (see its
 * own javadoc), but that only works if THIS loader is the one deciding when
 * {@code Bootstrap.bootStrap()} runs. Anything that reaches {@code BuiltInRegistries.bootStrap(...)}
 * by some other path (a different plugin, a future Paper version restructuring its own startup,
 * a second call this loader didn't initiate) would freeze every registry without ever giving
 * mods a chance to register — permanently, since freezing is a one-way trip. Patching the method
 * itself removes that dependency on call order entirely: no matter who calls
 * {@code BuiltInRegistries.bootStrap(...)} or when, {@code onRegistriesPreFreeze()} is guaranteed
 * to run exactly once, immediately before the freeze that would otherwise lock mods out.
 *
 * Only ONE call site is patched: the INVOKESTATIC to {@code BuiltInRegistries.freeze()} itself.
 * The earlier {@code REGISTRY.freeze()} in the same method is a different call (an
 * INVOKEINTERFACE/INVOKEVIRTUAL on {@code Registry}, not a static call on
 * {@code BuiltInRegistries}) and is deliberately left untouched — that call only freezes the
 * outer "registry of registries" so no new registries can be created, not the individual
 * built-in registries mods still need to populate.
 *
 * NOTE ON FRAGILITY: like the other transformers in this package, this assumes the method's
 * name/descriptor and the exact shape of its body on your Paper build. If a future version
 * renames bootStrap/freeze or changes the descriptor, update TARGET_METHOD/TARGET_DESC/
 * FREEZE_METHOD accordingly — run
 * {@code javap -p net.minecraft.core.registries.BuiltInRegistries} against your server jar to
 * confirm.
 */
public class BuiltInRegistriesTransformer implements ClassFileTransformer {

    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String TARGET_CLASS = "net/minecraft/core/registries/BuiltInRegistries";
    private static final String TARGET_METHOD = "bootStrap";
    private static final String TARGET_DESC = "(Ljava/lang/Runnable;)V";
    private static final String FREEZE_METHOD = "freeze";
    private static final String FREEZE_DESC = "()V";

    private static final String HOOKS_CLASS = "ankhangbo/modloader/ModLoaderHooks";

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET_CLASS.equals(className)) return null;

        try {
            return patch(classfileBuffer, loader);
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + className + " — leaving class unmodified. "
                    + "Mods will only get to register into built-in registries if this loader's own "
                    + "call ordering (ModLoaderCore#finishVanillaBootstrap) happens to run first.", t);
            return null;
        }
    }

    private byte[] patch(byte[] classBytes, ClassLoader targetLoader) {
        ClassReader reader = new ClassReader(classBytes);
        ClassNode cn = new ClassNode();
        reader.accept(cn, ClassReader.EXPAND_FRAMES);

        boolean patched = false;
        for (MethodNode mn : cn.methods) {
            if (!mn.name.equals(TARGET_METHOD) || !mn.desc.equals(TARGET_DESC)) continue;

            for (AbstractInsnNode insn : mn.instructions.toArray()) {
                if (!(insn instanceof MethodInsnNode min)) continue;
                if (min.getOpcode() != Opcodes.INVOKESTATIC) continue;
                if (!min.owner.equals(TARGET_CLASS)) continue;
                if (!min.name.equals(FREEZE_METHOD) || !min.desc.equals(FREEZE_DESC)) continue;

                // Right before BuiltInRegistries.freeze(): call ModLoaderHooks.onRegistriesPreFreeze().
                InsnList before = new InsnList();
                before.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS_CLASS, "onRegistriesPreFreeze", "()V", false));
                mn.instructions.insertBefore(min, before);
                patched = true;
                // Exactly one call site matters here — bail out once found.
                break;
            }
        }

        if (patched) {
            LOGGER.info(() -> "Patched " + TARGET_CLASS + "." + TARGET_METHOD + "(Runnable) with "
                    + "onRegistriesPreFreeze() hook, right before the internal freeze() call");
        } else {
            LOGGER.warning(() -> "Loaded " + TARGET_CLASS + " but found no matching " + TARGET_METHOD
                    + TARGET_DESC + " call to " + TARGET_CLASS + "." + FREEZE_METHOD + FREEZE_DESC
                    + " — onRegistriesPreFreeze() will not fire from here. Your Paper build may use a "
                    + "different bootStrap()/freeze() shape; see this class' javadoc.");
        }

        // Same fix as WorldTickTransformer/MinecraftServerAsmTransformer: COMPUTE_FRAMES needs to
        // resolve common superclasses via Class.forName() using a classloader that can actually
        // see NMS/CraftBukkit — not this agent jar's own loader.
        ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS) {
            @Override
            protected ClassLoader getClassLoader() {
                return targetLoader;
            }
        };
        cn.accept(writer);
        return writer.toByteArray();
    }
}