package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.ListIterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;

/**
 * Replaces the real fabric-api {@code CreativeModeTabsMixin} on
 * {@code net.minecraft.world.item.CreativeModeTabs}:
 * <ol>
 *   <li>{@code validate()} — the original mixin cancels this entirely at {@code HEAD}
 *       ("defer the duplication checks to when fabric performs them"), so we just wipe the whole
 *       method body and replace it with a single {@code RETURN}.</li>
 *   <li>{@code buildAllTabContents(ItemDisplayParameters)} (private static) — tail-inject a call
 *       to {@code CreativeTabHooks.paginateTabs()} at every {@code RETURN}, same technique as
 *       {@code WorldTickTransformer}. The full pagination/duplicate-check logic that used to live
 *       in the mixin body is now plain Java in {@code CreativeTabHooks} — inserting bytecode
 *       directly inside {@code buildAllTabContents} itself means calling that public static hook
 *       method needs no reflection at all, regardless of {@code buildAllTabContents}' own
 *       visibility.</li>
 * </ol>
 */
public class CreativeModeTabsAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String TARGET_CLASS = "net/minecraft/world/item/CreativeModeTabs";
    private static final String HOOKS = "ankhangbo/modloader/compat/fabriccreativetab/CreativeTabHooks";

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET_CLASS.equals(className)) return null;

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            boolean patchedValidate = false;
            boolean patchedBuildAll = false;

            for (MethodNode mn : cn.methods) {
                if (mn.name.equals("validate") && mn.desc.equals("()V")) {
                    mn.instructions.clear();
                    if (mn.tryCatchBlocks != null) mn.tryCatchBlocks.clear();
                    mn.instructions.add(new InsnNode(Opcodes.RETURN));
                    patchedValidate = true;
                } else if (mn.name.equals("buildAllTabContents")
                        && mn.desc.equals("(Lnet/minecraft/world/item/CreativeModeTab$ItemDisplayParameters;)V")) {
                    ListIterator<AbstractInsnNode> it = mn.instructions.iterator();
                    while (it.hasNext()) {
                        AbstractInsnNode insn = it.next();
                        if (insn.getOpcode() == Opcodes.RETURN) {
                            InsnList before = new InsnList();
                            before.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "paginateTabs", "()V", false));
                            mn.instructions.insertBefore(insn, before);
                        }
                    }
                    patchedBuildAll = true;
                }
            }

            if (!patchedValidate) {
                LOGGER.warning(TARGET_CLASS + ": did not find validate()V — vanilla's duplicate-position "
                        + "check may throw for perfectly valid Fabric-paginated tabs. Your Paper build may "
                        + "have renamed/changed this method.");
            }
            if (!patchedBuildAll) {
                LOGGER.warning(TARGET_CLASS + ": did not find buildAllTabContents(ItemDisplayParameters) — "
                        + "modded creative mode tabs will not be paginated. Your Paper build may have "
                        + "renamed/changed this method.");
            }
            if (!patchedValidate && !patchedBuildAll) return null;

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + TARGET_CLASS + " (cancelled validate(), added pagination hook to buildAllTabContents)");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + TARGET_CLASS + " — leaving class unmodified. "
                    + "Modded creative mode tab pagination will not work.", t);
            return null;
        }
    }
}
