package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;

/**
 * Replaces {@code DebugLevelSourceAccessor}'s {@code @Mutable} annotation, which tells real Mixin
 * to strip {@code ACC_FINAL} from a field before the class loads (necessary because a
 * {@code private static final} field can otherwise only ever be assigned once, inside its own
 * {@code <clinit>} — the JVM verifier enforces this even for code inside the declaring class
 * itself, so there's no way around it except editing the field's access flags before the class is
 * defined). This transformer does the same thing directly: clears {@code ACC_FINAL} on
 * {@code DebugLevelSource.ALL_BLOCKS}/{@code GRID_WIDTH}/{@code GRID_HEIGHT}. Actually writing to
 * them afterward is done via plain reflection in
 * {@link ankhangbo.modloader.compat.fabricregistry.RegistrySyncAccessors}.
 */
public class DebugLevelSourceAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");
    private static final String TARGET = "net/minecraft/world/level/levelgen/DebugLevelSource";
    private static final Set<String> FIELDS = Set.of("ALL_BLOCKS", "GRID_WIDTH", "GRID_HEIGHT");

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!className.equals(TARGET)) return null;

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            int patchedCount = 0;
            for (FieldNode fn : cn.fields) {
                if (FIELDS.contains(fn.name) && (fn.access & Opcodes.ACC_FINAL) != 0) {
                    fn.access &= ~Opcodes.ACC_FINAL;
                    patchedCount++;
                }
            }

            if (patchedCount == 0) {
                LOGGER.warning(TARGET + ": none of ALL_BLOCKS/GRID_WIDTH/GRID_HEIGHT found as final fields — "
                        + "either field names changed, or they're already non-final. "
                        + "RegistrySyncAccessors writes to them will throw if the names actually changed.");
                return null;
            }
            if (patchedCount != 3) {
                LOGGER.warning(TARGET + ": only stripped ACC_FINAL from " + patchedCount + "/3 expected fields — "
                        + "run javap -p on your build to check field names.");
            }

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + className + " (stripped ACC_FINAL for fabric-registry-sync-v0 debug level source generation)");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + className + " — leaving class unmodified", t);
            return null;
        }
    }
}
