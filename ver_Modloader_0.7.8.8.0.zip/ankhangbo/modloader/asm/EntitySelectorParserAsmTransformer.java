package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Replaces the real fabric-api {@code EntitySelectorParserMixin}: makes
 * {@code net.fabricmc.fabric.api.command.v2.FabricEntitySelectorParser} a REAL, genuinely
 * implemented interface on {@code net.minecraft.commands.arguments.selector.EntitySelectorParser}
 * — same technique as {@link PacketContextProviderAsmTransformer} (see its javadoc for why a real
 * interface is worth the extra ASM, vs. a side-table-only approach: 3rd-party mod source calls
 * {@code parser.setCustomFlag(...)}/{@code .getCustomFlag(...)} directly on the vanilla type).
 *
 * <p>Unlike {@code PacketContextProviderAsmTransformer} there's no existing instance field to
 * delegate through — the "flags" state is brand new — so the two injected methods forward to a
 * {@code WeakHashMap}-backed side table in {@code CommandHooks} instead of a genuinely-injected
 * field (adding new instance fields via ASM is possible but meaningfully more fragile than a side
 * table keyed by the instance itself, and {@code EntitySelectorParser} instances are short-lived
 * per-parse objects so a {@code WeakHashMap} is a perfectly fine backing store here).
 */
public class EntitySelectorParserAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String TARGET_CLASS = "net/minecraft/commands/arguments/selector/EntitySelectorParser";
    private static final String IFACE = "net/fabricmc/fabric/api/command/v2/FabricEntitySelectorParser";
    private static final String HOOKS = "ankhangbo/modloader/compat/fabriccommand/CommandHooks";
    private static final String IDENTIFIER_DESC = "Lnet/minecraft/resources/Identifier;";

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET_CLASS.equals(className)) return null;

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            if (cn.interfaces.contains(IFACE)) return null; // already patched

            cn.interfaces.add(IFACE);
            cn.methods.add(setCustomFlagMethod());
            cn.methods.add(getCustomFlagMethod());

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + TARGET_CLASS + " to genuinely implement FabricEntitySelectorParser");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to add FabricEntitySelectorParser to " + TARGET_CLASS
                    + " — leaving class unmodified. 3rd-party mod code calling .setCustomFlag()/.getCustomFlag() "
                    + "on this class will get the interface's throwing default.", t);
            return null;
        }
    }

    /** {@code public void setCustomFlag(Identifier key, boolean value) { CommandHooks.setCustomFlag(this, key, value); }} */
    private MethodNode setCustomFlagMethod() {
        MethodNode mn = new MethodNode(Opcodes.ACC_PUBLIC, "setCustomFlag", "(" + IDENTIFIER_DESC + "Z)V", null, null);
        mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
        mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 1));
        mn.instructions.add(new VarInsnNode(Opcodes.ILOAD, 2));
        mn.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "setCustomFlag",
                "(L" + TARGET_CLASS + ";" + IDENTIFIER_DESC + "Z)V", false));
        mn.instructions.add(new InsnNode(Opcodes.RETURN));
        return mn;
    }

    /** {@code public boolean getCustomFlag(Identifier key) { return CommandHooks.getCustomFlag(this, key); }} */
    private MethodNode getCustomFlagMethod() {
        MethodNode mn = new MethodNode(Opcodes.ACC_PUBLIC, "getCustomFlag", "(" + IDENTIFIER_DESC + ")Z", null, null);
        mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
        mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 1));
        mn.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "getCustomFlag",
                "(L" + TARGET_CLASS + ";" + IDENTIFIER_DESC + ")Z", false));
        mn.instructions.add(new InsnNode(Opcodes.IRETURN));
        return mn;
    }
}
