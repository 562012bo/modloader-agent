package ankhangbo.modloader.asm;

import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LocalVariableNode;
import org.objectweb.asm.tree.MethodNode;

/**
 * Finds the local-variable slot for a named local in scope at a given instruction, by reading the
 * compiled method's LocalVariableTable — the exact same debug-info attribute MixinExtras' own
 * {@code @Local(name = "...")} relies on internally.
 *
 * IMPORTANT CAVEAT: this only works if the class file being patched still has debug info
 * (javac's default -g, which includes LocalVariableTable) for that method. Most Paper/Mojang-mapped
 * builds do keep this, but if a specific build strips it, every lookup here returns -1 and the
 * corresponding hook simply won't fire (see the null-guards in FabricLifecycleHooks) instead of
 * crashing the transform. If you hit that in practice, the only reliable fix is to keep the
 * original Mixin (with MixinExtras) for that one method instead of this ASM path.
 */
final class LocalVarFinder {
    private LocalVarFinder() {}

    /**
     * @return the local variable slot index, or -1 if no variable named {@code name} is in scope
     *         at instruction {@code at} (either the table is missing, or the name doesn't match).
     */
    static int findLocal(MethodNode mn, AbstractInsnNode at, String name) {
        if (mn.localVariables == null) return -1;
        InsnList il = mn.instructions;
        int atIndex = il.indexOf(at);
        int best = -1;
        int bestWidth = Integer.MAX_VALUE;
        for (LocalVariableNode lv : mn.localVariables) {
            if (!lv.name.equals(name)) continue;
            int startIdx = il.indexOf(lv.start);
            int endIdx = il.indexOf(lv.end);
            if (atIndex < startIdx || atIndex > endIdx) continue;
            // Prefer the narrowest enclosing scope in case of duplicate names in nested blocks.
            int width = endIdx - startIdx;
            if (width < bestWidth) {
                bestWidth = width;
                best = lv.index;
            }
        }
        return best;
    }
}
