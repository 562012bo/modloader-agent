package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.MethodNode;

import ankhangbo.modloader.accesswidener.AccessWidenerRegistry;

/**
 * Applies every mod's merged {@code .accesswidener} rules (see {@link AccessWidenerRegistry}) to
 * matching classes as they load — vanilla/Paper classes AND other mods' classes alike, same as
 * real fabric-loader. Runs first in the transformer chain (registered before Mixin/other ASM
 * transformers in {@code ModLoaderAgent}) since widened access is often a precondition for a
 * ported mod's OWN Mixins to even apply cleanly.
 *
 * <p>Rule semantics (matches real fabric-loader):
 * <ul>
 *   <li>{@code accessible class} — class access flags -> public.</li>
 *   <li>{@code accessible field/method} — member access flags -> public.</li>
 *   <li>{@code extendable class} — strip {@code ACC_FINAL} from the class.</li>
 *   <li>{@code extendable method} — strip {@code ACC_FINAL}; bump visibility to at least
 *       {@code protected} (never narrows an already-public member).</li>
 *   <li>{@code mutable field} — strip {@code ACC_FINAL} from the field.</li>
 * </ul>
 */
public class AccessWidenerAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/AccessWidener");

	@Override
	public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
							 ProtectionDomain protectionDomain, byte[] classfileBuffer) {
		// Bỏ qua nếu className null hoặc thuộc package accesswidener (để tránh LinkageError)
		if (className == null || className.startsWith("ankhangbo/modloader/accesswidener/")) {
			return null;
		}

		if (!AccessWidenerRegistry.hasAnyRulesFor(className)) return null;

		AccessWidenerRegistry.ClassRules rules = AccessWidenerRegistry.rulesFor(className);
		LOGGER.info(() -> className + ": has " + rules.classAccess.size() + " class rule(s), "
				+ rules.fieldAccess.size() + " field rule(s), " + rules.methodAccess.size()
				+ " method rule(s), " + rules.interfacesToInject.size() + " inject-interface rule(s) — applying now");

		// Every key present here at the end was declared in some mod's .accesswidener/.classtweaker
		// but never matched an actual field/method in this class file — almost always a typo'd name
		// or wrong method descriptor in the rule file, or the rule targets a different version of
		// this class than what's actually running. This was PREVIOUSLY a silent no-op (the rule
		// just sat there unused, no log, no error) — exactly the "ran, no error shown, but access
		// still fails" symptom. Now reported loudly.
		Set<String> unmatchedFieldRules = new java.util.HashSet<>(rules.fieldAccess.keySet());
		Set<String> unmatchedMethodRules = new java.util.HashSet<>(rules.methodAccess.keySet());

		try {
			ClassReader reader = new ClassReader(classfileBuffer);
			ClassNode cn = new ClassNode();
			reader.accept(cn, ClassReader.EXPAND_FRAMES);

			// BUG FIX: "inject-interface <target> <iface>" (the classTweaker directive) was
			// parsed correctly by AccessWidenerReader and stored correctly in
			// AccessWidenerRegistry.ClassRules#interfacesToInject, but nothing ever read that
			// set back out here -- the directive was a silent no-op at the bytecode level.
			// classAccess/fieldAccess/methodAccess below only cover plain accessWidener
			// visibility rules, not interface injection. Add each requested interface to the
			// class' real `interfaces` list, same as real fabric-loader's inject-interface.
			for (String ifaceInternalName : rules.interfacesToInject) {
				if (!cn.interfaces.contains(ifaceInternalName)) {
					cn.interfaces.add(ifaceInternalName);
					LOGGER.info(className + ": injected interface " + ifaceInternalName + " (classTweaker inject-interface)");
				}
			}

			for (AccessWidenerRegistry.Access access : rules.classAccess) {
				switch (access) {
					case ACCESSIBLE -> cn.access = makePublic(cn.access);
					case EXTENDABLE -> cn.access &= ~Opcodes.ACC_FINAL;
					case MUTABLE -> LOGGER.warning(className + ": 'mutable class' is not a valid access widener rule — ignoring");
				}
			}

			for (FieldNode fn : cn.fields) {
				String key = fn.name + fn.desc;
				Set<AccessWidenerRegistry.Access> fieldRules = rules.fieldAccess.get(key);
				if (fieldRules == null) continue;
				unmatchedFieldRules.remove(key);
				for (AccessWidenerRegistry.Access access : fieldRules) {
					switch (access) {
						case ACCESSIBLE -> { fn.access = makePublic(fn.access); LOGGER.info(className + "#" + fn.name + ": widened to public"); }
						case MUTABLE -> { fn.access &= ~Opcodes.ACC_FINAL; LOGGER.info(className + "#" + fn.name + ": removed 'final'"); }
						case EXTENDABLE -> LOGGER.warning(className + "#" + fn.name + ": 'extendable field' is not a valid access widener rule — ignoring");
					}
				}
			}

			for (MethodNode mn : cn.methods) {
				String key = mn.name + mn.desc;
				Set<AccessWidenerRegistry.Access> methodRules = rules.methodAccess.get(key);
				if (methodRules == null) continue;
				unmatchedMethodRules.remove(key);
				for (AccessWidenerRegistry.Access access : methodRules) {
					switch (access) {
						case ACCESSIBLE -> { mn.access = makePublic(mn.access); LOGGER.info(className + "#" + mn.name + mn.desc + ": widened to public"); }
						case EXTENDABLE -> {
							mn.access &= ~Opcodes.ACC_FINAL;
							mn.access = atLeastProtected(mn.access);
							LOGGER.info(className + "#" + mn.name + mn.desc + ": removed 'final', bumped to at least protected");
						}
						case MUTABLE -> LOGGER.warning(className + "#" + mn.name + mn.desc + ": 'mutable method' is not a valid access widener rule — ignoring");
					}
				}
			}

			if (!unmatchedFieldRules.isEmpty() || !unmatchedMethodRules.isEmpty()) {
				LOGGER.warning(className + ": " + unmatchedFieldRules.size() + " field rule(s) and "
						+ unmatchedMethodRules.size() + " method rule(s) did NOT match anything in this "
						+ "actual class file — almost always a typo'd name or wrong descriptor in the "
						+ ".accesswidener/.classtweaker file, or this class doesn't look the way the mod "
						+ "author expected (wrong Minecraft version?). Unmatched field keys (name+descriptor): "
						+ unmatchedFieldRules + " — Unmatched method keys (name+descriptor): " + unmatchedMethodRules);
			}

			ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
			cn.accept(writer);
			LOGGER.info(className + ": access widener rules applied");
			return writer.toByteArray();
		} catch (Throwable t) {
			LOGGER.log(Level.SEVERE, "Failed to apply access widener rules to " + className + " — leaving class unmodified", t);
			return null;
		}
	}

    private static int makePublic(int access) {
        access &= ~(Opcodes.ACC_PRIVATE | Opcodes.ACC_PROTECTED);
        return access | Opcodes.ACC_PUBLIC;
    }

    private static int atLeastProtected(int access) {
        if ((access & (Opcodes.ACC_PUBLIC | Opcodes.ACC_PROTECTED)) != 0) return access; // already public/protected
        access &= ~Opcodes.ACC_PRIVATE;
        return access | Opcodes.ACC_PROTECTED;
    }
}
