package ankhangbo.modloader.asm;

import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.bukkit.event.entity.CreatureSpawnEvent;

import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ChunkMap;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.packs.resources.CloseableResourceManager;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.chunk.LevelChunk;

/**
 * Plain static methods that the ASM transformers below call directly (INVOKESTATIC), instead
 * of a Mixin @Inject/@WrapOperation handler. Each method here is a byte-for-byte port of the
 * corresponding fabric-api mixin handler body — see net.fabricmc.fabric.mixin.event.lifecycle
 * for the originals this replaces.
 *
 * IMPORTANT — why everything fabric-api-related here goes through reflection:
 * This class gets defined by whatever classloader loads net.minecraft.server.MinecraftServer
 * (Paperclip's raw URLClassLoader — see ClassLoaderBridge). fabric-api's classes
 * (net.fabricmc.fabric.api.*, net.fabricmc.fabric.impl.*) are only loaded by this project's
 * MixinAwareClassLoader, a CHILD of that URLClassLoader. Parent-first delegation means the child
 * (MixinAwareClassLoader) can see everything the parent (URLClassLoader) has — but never the
 * reverse. So this class, once defined by the parent, structurally CANNOT have a normal
 * compile-time/typed reference to any net.fabricmc.* class (import + static method call) — the
 * JVM would throw NoClassDefFoundError trying to resolve it, exactly like it did before this file
 * was rewritten. Every fabric-api touchpoint below goes through {@link #fire} / plain reflection
 * instead, using {@link #modClassLoader} (set once, from ModLoaderHooks, to the same
 * "realClassLoader"/MixinAwareClassLoader that already knows how to reach ModLoaderCore) as the
 * explicit loader to resolve those classes from — exactly the same reflection-bridge pattern this
 * project already uses for ModLoaderHooks -> ModLoaderCore, for the identical reason.
 *
 * NMS types (MinecraftServer, ServerLevel, LivingEntity, ...) and Bukkit types
 * (CreatureSpawnEvent) are fine to reference normally/typed here — those ARE visible from the
 * parent URLClassLoader (that's the loader that defines them in the first place).
 */
public final class FabricLifecycleHooks {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");
    private static volatile ClassLoader modClassLoader;

    private FabricLifecycleHooks() {}

    /**
     * Call once, early, from ModLoaderHooks (or wherever you have "realClassLoader"/
     * MixinAwareClassLoader in hand) — see ModLoaderHooks.ensureCoreBootstrapped(). Safe to call
     * more than once; last call wins (idempotent in practice since it's always the same loader).
     */
    public static void setModClassLoader(ClassLoader loader) {
        modClassLoader = loader;
        LOGGER.info("FabricLifecycleHooks now resolving fabric-api classes via " + loader);
    }

    /**
     * Reflectively does {@code EventsClass.FIELD.invoker().methodName(args...)}. This is the
     * shape of every fabric-api event: a static field of type Event<T>, whose invoker() returns
     * a T (a single-method functional interface) that we call by name.
     */
    private static void fire(String eventsClassName, String fieldName, String methodName, Object... args) {
        ClassLoader cl = modClassLoader;
        if (cl == null) {
            LOGGER.warning("modClassLoader not set yet — skipping " + eventsClassName + "." + fieldName
                    + " (this should only happen if a hook fires before ModLoaderHooks.ensureCoreBootstrapped ran)");
            return;
        }
        try {
            Class<?> eventsClass = Class.forName(eventsClassName, true, cl);
            Object event = eventsClass.getField(fieldName).get(null);
            Object invoker = event.getClass().getMethod("invoker").invoke(event);
            Method target = findByNameAndArity(invoker.getClass(), methodName, args.length);
            target.setAccessible(true);
            target.invoke(invoker, args);
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to fire " + eventsClassName + "." + fieldName, t);
        }
    }

    /** Same as {@link #fire}, but for events whose invoker method returns a value (e.g. boolean for ALLOW_LOAD). */
    private static Object fireReturning(String eventsClassName, String fieldName, String methodName, Object... args) {
        ClassLoader cl = modClassLoader;
        if (cl == null) {
            LOGGER.warning("modClassLoader not set yet — skipping " + eventsClassName + "." + fieldName);
            return null;
        }
        try {
            Class<?> eventsClass = Class.forName(eventsClassName, true, cl);
            Object event = eventsClass.getField(fieldName).get(null);
            Object invoker = event.getClass().getMethod("invoker").invoke(event);
            Method target = findByNameAndArity(invoker.getClass(), methodName, args.length);
            target.setAccessible(true);
            return target.invoke(invoker, args);
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to fire " + eventsClassName + "." + fieldName, t);
            return null;
        }
    }

    private static Method findByNameAndArity(Class<?> cls, String name, int arity) throws NoSuchMethodException {
        for (Method m : cls.getMethods()) {
            if (m.getName().equals(name) && m.getParameterCount() == arity) {
                return m;
            }
        }
        throw new NoSuchMethodException(name + "/" + arity + " on " + cls);
    }

    private static final String LIFECYCLE = "net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents";
    private static final String TICK = "net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents";
    private static final String LEVEL = "net.fabricmc.fabric.api.event.lifecycle.v1.ServerLevelEvents";
    private static final String CHUNK = "net.fabricmc.fabric.api.event.lifecycle.v1.ServerChunkEvents";
    private static final String ENTITY = "net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents";
    private static final String BLOCK_ENTITY = "net.fabricmc.fabric.api.event.lifecycle.v1.ServerBlockEntityEvents";

    // ---- MinecraftServerMixin replacements ----

    public static void serverStarting(MinecraftServer server) {
        fire(LIFECYCLE, "SERVER_STARTING", "onServerStarting", server);
    }

    public static void serverStarted(MinecraftServer server) {
        fire(LIFECYCLE, "SERVER_STARTED", "onServerStarted", server);
    }

    public static void serverStopping(MinecraftServer server) {
        fire(LIFECYCLE, "SERVER_STOPPING", "onServerStopping", server);
    }

    public static void serverStopped(MinecraftServer server) {
        fire(LIFECYCLE, "SERVER_STOPPED", "onServerStopped", server);
    }

    public static void startServerTick(MinecraftServer server) {
        fire(TICK, "START_SERVER_TICK", "onStartTick", server);
    }

    public static void endServerTick(MinecraftServer server) {
        fire(TICK, "END_SERVER_TICK", "onEndTick", server);
    }

    /** Called right after Map.put(dimension, level) inside createLevels — matches the original @WrapOperation. */
    public static void levelLoad(MinecraftServer server, ServerLevel level) {
        fire(LEVEL, "LOAD", "onLevelLoad", server, level);
    }

    /** Called right before ServerLevel.close() inside stopServer — matches the original @Local-based @Inject. */
    public static void levelUnload(MinecraftServer server, ServerLevel level) {
        fire(LEVEL, "UNLOAD", "onLevelUnload", server, level);
    }

    public static void startDataPackReload(MinecraftServer server, CloseableResourceManager resourceManager) {
        fire(LIFECYCLE, "START_DATA_PACK_RELOAD", "startDataPackReload", server, resourceManager);
    }

    /**
     * Called with the CompletableFuture<Void> that reloadResources(...) is about to return.
     * Does the handleAsync(...) chaining itself in plain Java, instead of the ASM transformer
     * having to synthesize a new lambda/invokedynamic call site.
     */
    public static void endDataPackReload(MinecraftServer server, CloseableResourceManager resourceManager,
                                          CompletableFuture<Void> future) {
        if (future == null) return;
        future.handleAsync((value, throwable) -> {
            fire(LIFECYCLE, "END_DATA_PACK_RELOAD", "endDataPackReload", server, resourceManager, throwable == null);
            return value;
        }, server);
    }

    public static void beforeSave(MinecraftServer server, boolean flush, boolean force) {
        fire(LIFECYCLE, "BEFORE_SAVE", "onBeforeSave", server, flush, force);
    }

    public static void afterSave(MinecraftServer server, boolean flush, boolean force) {
        fire(LIFECYCLE, "AFTER_SAVE", "onAfterSave", server, flush, force);
    }

    // ---- ChunkMapMixin replacement ----

    /** Called right before ChunkMap.save(chunk) inside lambda$scheduleUnload$0. */
    public static void chunkUnload(ServerLevel level, ChunkAccess chunk) {
        if (chunk instanceof LevelChunk levelChunk) {
            fire(CHUNK, "CHUNK_UNLOAD", "onChunkUnload", level, levelChunk);
        }
    }

    // ---- LivingEntityMixin replacement ----

    /**
     * Called right after Map.put(slot, current) inside collectEquipmentChanges(). "previous" is
     * looked up from the method's own LocalVariableTable at the call site (see
     * LivingEntityAsmTransformer) — this is the ONE value here that is not a direct argument of
     * the traced call, and therefore the one part of this port that depends on debug info
     * (LocalVariableTable) being present in the compiled class, exactly like MixinExtras' own
     * @Local relies on the same table. If your build strips debug info this will silently not
     * fire (see the null-guard below) instead of crashing.
     */
    public static void equipmentChange(LivingEntity entity, EquipmentSlot slot, ItemStack previous, ItemStack current) {
        if (slot == null || previous == null || current == null) return;
        fire(ENTITY, "EQUIPMENT_CHANGE", "onChange", entity, slot, previous, current);
    }

    // ---- LevelChunkMixin replacement ----

    /** Called right after Map.put(pos, blockEntity) inside setBlockEntity(). */
    public static void blockEntityLoad(BlockEntity removedBlockEntity, BlockEntity blockEntity, LevelChunk chunk) {
        if (blockEntity != null && blockEntity != removedBlockEntity && chunk.getLevel() instanceof ServerLevel serverLevel) {
            fire(BLOCK_ENTITY, "BLOCK_ENTITY_LOAD", "onLoad", blockEntity, serverLevel);
        }
    }

    /** Called from the two removeBlockEntity-adjacent hooks and the map.remove redirect below. */
    public static void blockEntityUnload(BlockEntity removed, LevelChunk chunk) {
        if (removed != null && chunk.getLevel() instanceof ServerLevel serverLevel) {
            fire(BLOCK_ENTITY, "BLOCK_ENTITY_UNLOAD", "onUnload", removed, serverLevel);
        }
    }

    /**
     * Full replacement for the @Redirect on Map.remove(Object) inside getBlockEntity(...). Does
     * the actual map.remove(key) itself (the original call site is deleted entirely and replaced
     * with a call to this method), then fires the event — same net effect as the Mixin @Redirect.
     */
    @SuppressWarnings("unchecked")
    public static Object redirectedMapRemove(Map<?, ?> map, Object key, LevelChunk chunk) {
        Object removed = ((Map<Object, Object>) map).remove(key);
        if (removed instanceof BlockEntity be) {
            blockEntityUnload(be, chunk);
        }
        return removed;
    }

    // ---- PersistentEntitySectionManagerMixin replacement ----

    /**
     * Called at the head of addEntity(...). Returns false to mean "cancel the add" (mirrors
     * cir.cancel() in the original — the ASM transformer must early-return when this returns
     * false, see PersistentEntitySectionManagerAsmTransformer).
     *
     * NOTE: this Paper/Moonrise-based Entity class has no spawnReason() method the way vanilla/
     * Fabric-mapped Entity does — it only exposes the Bukkit-level field
     * `entity.spawnReason` (org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason). The mapping
     * below is a BEST-EFFORT approximation to the Fabric EntitySpawnReason enum so
     * ServerEntityEvents.ALLOW_LOAD keeps working; it is not a guaranteed 1:1 semantic match.
     * Review/extend bukkitReasonToFabric(...) for the specific spawn reasons your mods care about.
     *
     * fabric_setLoadedFromDisk is also called reflectively here (not cast to the
     * net.fabricmc.fabric.impl.event.lifecycle.EntityLoadDataSetter interface) for the same
     * cross-classloader reason as everything else in this file — we only need the method by name
     * on entity's own (already-loaded, already-visible) runtime class, not the interface type.
     */
    public static boolean beforeAddEntity(Entity entity, boolean loaded) {
        try {
            Method setLoadedFromDisk = entity.getClass().getMethod("fabric_setLoadedFromDisk", boolean.class);
            setLoadedFromDisk.setAccessible(true);
            setLoadedFromDisk.invoke(entity, loaded);
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to call fabric_setLoadedFromDisk on " + entity.getClass(), t);
        }

        if (!(entity.level() instanceof ServerLevel serverLevel)) {
            return true;
        }

        EntitySpawnReason reason = bukkitReasonToFabric(entity.spawnReason);
        Object result = fireReturning(ENTITY, "ALLOW_LOAD", "onAllowLoad", entity, serverLevel, reason, loaded);
        return !(result instanceof Boolean b) || b; // default to "allow" if the event couldn't be fired at all
    }

    /**
     * Switches on {@code bukkitReason.name()} (a String) rather than the enum constants
     * themselves. Different Paper/Spigot API versions add/remove/rename SpawnReason constants
     * over time (e.g. END_GATEWAY does not exist on every version) — matching by name means this
     * always compiles, and simply falls through to LOAD for any reason your API version doesn't
     * have under that exact name. Extend the cases below for whatever reasons your mods need.
     */
    private static EntitySpawnReason bukkitReasonToFabric(CreatureSpawnEvent.SpawnReason bukkitReason) {
        if (bukkitReason == null) return EntitySpawnReason.LOAD;
        return switch (bukkitReason.name()) {
            case "NATURAL" -> EntitySpawnReason.NATURAL;
            case "CHUNK_GEN" -> EntitySpawnReason.CHUNK_GENERATION;
            case "SPAWNER", "SPAWNER_EGG" -> EntitySpawnReason.SPAWNER;
            case "BREEDING", "EGG" -> EntitySpawnReason.BREEDING;
            case "COMMAND", "CUSTOM" -> EntitySpawnReason.COMMAND;
            case "DISPENSE_EGG" -> EntitySpawnReason.DISPENSER;
            case "BUCKET" -> EntitySpawnReason.BUCKET;
            case "RAID", "PATROL" -> EntitySpawnReason.PATROL;
            case "NETHER_PORTAL", "END_GATEWAY", "END_PORTAL" -> EntitySpawnReason.DIMENSION_TRAVEL;
            case "REINFORCEMENTS" -> EntitySpawnReason.REINFORCEMENT;
            default -> EntitySpawnReason.LOAD;
        };
    }

    // ---- ServerPlayerGameModeMixin replacements (fabric-events-interaction-v0) ----
    //
    // Unlike the lifecycle events above (void, fire-and-forget), these need a real return value
    // (InteractionResult, or boolean for the block-break BEFORE check) flowing back into vanilla
    // code that decides whether to cancel. InteractionResult itself is an NMS type — visible from
    // this class' own (bukkitLoader) defining loader just fine — so unlike the AttackBlockCallback/
    // UseBlockCallback/UseItemCallback/PlayerBlockBreakEvents types themselves (net.fabricmc.fabric.*,
    // only visible via modClassLoader, hence still reflection-only below), the PASS comparison and
    // the return type can be written as completely normal, directly-typed Java. That also sidesteps
    // hand-rolling a GETSTATIC ... PASS field access in raw ASM bytecode (fragile: silently assumes
    // an exact declared field type that can change between game versions) — javac resolves this
    // correctly against the real compile-time classpath instead.

    private static final String PLAYER_EVENTS = "net.fabricmc.fabric.api.event.player";

	public static net.minecraft.world.InteractionResult attackBlock(
			net.minecraft.server.level.ServerPlayer player,
			net.minecraft.world.level.Level level,
			net.minecraft.world.InteractionHand hand, 
			net.minecraft.core.BlockPos pos,
			net.minecraft.core.Direction direction) {
		Object result = fireReturning(PLAYER_EVENTS + ".AttackBlockCallback", "EVENT", "interact",
				player, level, hand, pos, direction);
		return result instanceof net.minecraft.world.InteractionResult r ? r : net.minecraft.world.InteractionResult.PASS;
	}

    public static net.minecraft.world.InteractionResult useBlock(
            net.minecraft.world.entity.player.Player player, net.minecraft.world.level.Level level,
            net.minecraft.world.InteractionHand hand, net.minecraft.world.phys.BlockHitResult hitResult) {
        Object result = fireReturning(PLAYER_EVENTS + ".UseBlockCallback", "EVENT", "interact",
                player, level, hand, hitResult);
        return result instanceof net.minecraft.world.InteractionResult r ? r : net.minecraft.world.InteractionResult.PASS;
    }

    public static net.minecraft.world.InteractionResult useItem(
            net.minecraft.world.entity.player.Player player, net.minecraft.world.level.Level level,
            net.minecraft.world.InteractionHand hand) {
        Object result = fireReturning(PLAYER_EVENTS + ".UseItemCallback", "EVENT", "interact",
                player, level, hand);
        return result instanceof net.minecraft.world.InteractionResult r ? r : net.minecraft.world.InteractionResult.PASS;
    }

    /** @return {@code false} to cancel the break (matches real PlayerBlockBreakEvents.Before) */
    public static boolean blockBreakBefore(
            net.minecraft.world.level.Level level, net.minecraft.world.entity.player.Player player,
            net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state,
            BlockEntity blockEntity) {
        Object result = fireReturning(PLAYER_EVENTS + ".PlayerBlockBreakEvents", "BEFORE", "beforeBlockBreak",
                level, player, pos, state, blockEntity);
        // Same "default" a zero-listener real Event<Before> would return, and what we want if
        // modClassLoader isn't ready yet / something threw: don't cancel anything.
        return !(result instanceof Boolean b) || b;
    }

    public static void blockBreakCanceled(
            net.minecraft.world.level.Level level, net.minecraft.world.entity.player.Player player,
            net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state,
            BlockEntity blockEntity) {
        fire(PLAYER_EVENTS + ".PlayerBlockBreakEvents", "CANCELED", "onBlockBreakCanceled",
                level, player, pos, state, blockEntity);
    }

    public static boolean isPass(net.minecraft.world.InteractionResult result) {
        return result == net.minecraft.world.InteractionResult.PASS;
    }

    public static void blockBreakAfter(
            net.minecraft.world.level.Level level, net.minecraft.world.entity.player.Player player,
            net.minecraft.core.BlockPos pos, net.minecraft.world.level.block.state.BlockState state,
            BlockEntity blockEntity) {
        fire(PLAYER_EVENTS + ".PlayerBlockBreakEvents", "AFTER", "afterBlockBreak",
                level, player, pos, state, blockEntity);
    }

    public static net.minecraft.world.InteractionResult attackEntity(
            net.minecraft.world.entity.player.Player player, 
            net.minecraft.world.level.Level level,
            net.minecraft.world.InteractionHand hand, 
            net.minecraft.world.entity.Entity target) {
        Object result = fireReturning(
            "net.fabricmc.fabric.api.event.player.AttackEntityCallback", 
            "EVENT", 
            "interact",
            player, level, hand, target, null);
        return result instanceof net.minecraft.world.InteractionResult r 
            ? r : net.minecraft.world.InteractionResult.PASS;
    }
}