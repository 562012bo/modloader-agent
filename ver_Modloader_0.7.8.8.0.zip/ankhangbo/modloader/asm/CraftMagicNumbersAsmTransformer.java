package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Fixes a real, confirmed bug in Paper's own {@code CraftMagicNumbers}: its static initializer
 * loops over EVERY item in {@code BuiltInRegistries.ITEM} (this includes modded items — the
 * registry is already frozen with mods' items in it by the time this class initializes) and does:
 *
 * <pre>
 *   ITEM_MATERIAL.put(item, Material.getMaterial(key.getPath().toUpperCase()));
 * </pre>
 *
 * For a modded item like {@code naturescompass:naturescompass}, {@code Material.getMaterial(...)}
 * legitimately returns {@code null} (no such vanilla enum constant exists) — and that {@code null}
 * gets stored as the map VALUE for that item's key, not omitted.
 *
 * {@code getMaterial(Item)} then does {@code ITEM_MATERIAL.getOrDefault(item, Material.AIR)}.
 * {@code Map.getOrDefault} only substitutes the default when the KEY IS ABSENT — since the modded
 * item's key IS present (mapped to {@code null}), it faithfully returns that stored {@code null}
 * instead of falling back to {@code Material.AIR}. Every caller that assumes
 * {@code CraftMagicNumbers.getMaterial(item)} is never null (e.g. {@code CraftItemStack}'s
 * constructor calling {@code getType().isLegacy()}) then NPEs — this is exactly what produces
 * "Cannot invoke org.bukkit.Material.isLegacy() because ... getType() is null" whenever a modded
 * item touches crafting-recipe / inventory-click code paths.
 *
 * This patch fully replaces {@code getMaterial(Item)}'s body with a null-safe equivalent:
 * <pre>
 *   Material m = ITEM_MATERIAL.get(item);
 *   return m != null ? m : Material.AIR;
 * </pre>
 * i.e. treat a null-valued entry the same as an absent one. Nothing else about
 * {@code CraftMagicNumbers} changes — modded items still report as {@code Material.AIR} to any
 * Bukkit API that asks (the same generic-but-safe fallback vanilla already uses for genuinely
 * unmapped items), they just no longer NPE the caller.
 */
public class CraftMagicNumbersAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");
    private static final String TARGET = "org/bukkit/craftbukkit/util/CraftMagicNumbers";
    private static final String ITEM_DESC = "Lnet/minecraft/world/item/Item;";
    private static final String MATERIAL_DESC = "Lorg/bukkit/Material;";
    private static final String GET_MATERIAL_DESC = "(" + ITEM_DESC + ")" + MATERIAL_DESC;

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET.equals(className)) return null;

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            boolean patched = patchGetMaterial(cn);
            if (!patched) {
                LOGGER.warning(TARGET + ": getMaterial(Item) not found or not in the expected shape — "
                        + "modded items may still NPE in CraftItemStack/recipe code paths. If Paper's "
                        + "CraftMagicNumbers source changed, update CraftMagicNumbersAsmTransformer to match.");
                return null;
            }

            ClassWriter writer = new ClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS);
            cn.accept(writer);
            LOGGER.info("Patched " + TARGET + ".getMaterial(Item) — modded items now safely fall back to "
                    + "Material.AIR instead of returning a stored null and NPE-ing callers.");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + TARGET + " — modded items will still NPE in "
                    + "CraftItemStack/recipe code paths (crafting, container clicks, ...)", t);
            return null;
        }
    }

    private boolean patchGetMaterial(ClassNode cn) {
        for (MethodNode mn : cn.methods) {
            if (!mn.name.equals("getMaterial") || !mn.desc.equals(GET_MATERIAL_DESC)) continue;
            if ((mn.access & Opcodes.ACC_STATIC) == 0) continue; // must be the static Item overload

            // Find the ITEM_MATERIAL field's exact declared type so we call the right Map.get(...).
            String mapDesc = null;
            for (var f : cn.fields) {
                if (f.name.equals("ITEM_MATERIAL")) {
                    mapDesc = f.desc;
                    break;
                }
            }
            if (mapDesc == null || !mapDesc.equals("Ljava/util/Map;")) return false;

            InsnList body = new InsnList();
            LabelNode nonNull = new LabelNode();

            // Material m = ITEM_MATERIAL.get(item);
            body.add(new FieldInsnNode(Opcodes.GETSTATIC, cn.name, "ITEM_MATERIAL", mapDesc));
            body.add(new VarInsnNode(Opcodes.ALOAD, 0)); // item param, slot 0 (static method)
            body.add(new MethodInsnNode(Opcodes.INVOKEINTERFACE, "java/util/Map", "get",
                    "(Ljava/lang/Object;)Ljava/lang/Object;", true));
            body.add(new TypeInsnNode(Opcodes.CHECKCAST, "org/bukkit/Material"));
            // return m != null ? m : Material.AIR;
            body.add(new InsnNode(Opcodes.DUP));
            body.add(new JumpInsnNode(Opcodes.IFNONNULL, nonNull));
            body.add(new InsnNode(Opcodes.POP));
            body.add(new FieldInsnNode(Opcodes.GETSTATIC, "org/bukkit/Material", "AIR", MATERIAL_DESC));
            body.add(nonNull);
            body.add(new InsnNode(Opcodes.ARETURN));

            mn.instructions.clear();
            mn.tryCatchBlocks.clear();
            mn.instructions.add(body);
            return true;
        }
        return false;
    }
}
