package ankhangbo.modloader.asm;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Method;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Collections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.jar.JarOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Our injected bytecode (in MinecraftServer, ChunkMap, LivingEntity, ...) calls static methods on
 * {@link FabricLifecycleHooks} via INVOKESTATIC. That only resolves at runtime if whatever
 * classloader loaded the PATCHED class can also see ankhangbo.modloader.asm.FabricLifecycleHooks.
 *
 * Paperclip loads the actual game classes through its own {@link URLClassLoader}, isolated from
 * our agent's own classpath, so that call fails with NoClassDefFoundError unless we do something
 * about it.
 *
 * IMPORTANT: we do NOT simply {@code addURL} our whole agent jar to that loader. This project's
 * own {@code MixinAwareClassLoader} ALSO loads (a mixin-transformed copy of) every class in
 * ankhangbo.modloader.* — including things like {@code ankhangbo.modloader.event.EventBus} and
 * {@code ModLoaderCore} that are totally unrelated to us. If the whole agent jar is added to
 * Paperclip's URLClassLoader (which is an ANCESTOR of MixinAwareClassLoader — parent-first
 * delegation), that URLClassLoader starts winning the race to define those classes itself,
 * un-transformed, before MixinAwareClassLoader ever gets a chance — a "split class" situation
 * where the same class name ends up as two different runtime types depending which loader defined
 * it, which is exactly the {@code LinkageError: loader constraint violation} /
 * {@code IllegalAccessError} you get from this.
 *
 * Instead, exactly like {@code ModLoaderAgent.exposeHooksToBootstrap}, we extract ONLY the
 * "hook/compat" packages actually referenced from injection call sites — see
 * {@link #PACKAGE_PREFIXES_TO_EXPOSE} — into their own tiny throwaway jar, and add ONLY that to
 * the target loader. Nothing else in ankhangbo.modloader.* becomes reachable through it, so
 * MixinAwareClassLoader keeps winning the race for everything it's actually supposed to own.
 *
 * <p>This list is PACKAGE-based, not a hand-picked class list (that was the previous design —
 * see git history / {@code CLASSES_TO_EXPOSE_Fabric} if you're looking for it — and it's exactly
 * what caused a real {@code NoClassDefFoundError: ankhangbo/modloader/compat/fabricloader
 * /SimpleVersion} crash: someone had deliberately commented that one class out of the list to
 * avoid a different problem, without realizing {@code FabricLoaderImpl}, which WAS in the list,
 * needed it directly in a static initializer). A per-class list needs updating by hand every
 * single time a new class is added anywhere under an exposed package — package-prefix matching
 * means new classes are picked up automatically the next time {@link #buildMinimalHooksJar()}
 * scans the agent jar's real entries.
 */
public final class ClassLoaderBridge {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");
    private static final Set<ClassLoader> PATCHED_LOADERS = Collections.newSetFromMap(new ConcurrentHashMap<>());
    // Keyed by "targetLoader identity + jar path" (NOT just targetLoader — unlike ensureHooksVisible,
    // this gets called once PER MOD JAR against the SAME bukkitLoader, so a per-loader-only guard
    // would silently skip every mod jar after the first one).
    private static final Set<String> EXPOSED_JARS = Collections.newSetFromMap(new ConcurrentHashMap<>());
    private static volatile boolean moduleOpened = false;

    /**
     * KIẾN TRÚC MỚI (thay cho list class thủ công CLASSES_TO_EXPOSE_Fabric cũ — đúng nguyên nhân
     * gây ra {@code NoClassDefFoundError: ankhangbo/modloader/compat/fabricloader/SimpleVersion}:
     * dev trước đã comment out SimpleVersion.class khỏi list vì sợ trùng class, nhưng quên rằng
     * FabricLoaderImpl (VẪN có trong list) cần nó ngay trong {@code <clinit>}. Một list tay không
     * bao giờ hết bug kiểu này — thêm 1 class mới ở bất kỳ package nào trong đây mà quên update
     * list là lại NoClassDefFoundError tiếp.
     *
     * <p>Thay vào đó: giống hệt {@link ankhangbo.modloader.MixinAwareClassLoader#loadClass}, định
     * tuyến theo PACKAGE PREFIX. Bất kỳ class nào nằm dưới 1 trong các prefix này đều tự động
     * được đưa vào minimal hooks jar — không cần biết trước tên class cụ thể. Đây CHÍNH LÀ "2
     * classloader, định tuyến rõ ràng" bạn muốn: {@code MixinAwareClassLoader} định tuyến
     * org.spongepowered.asm.* / org.objectweb.asm.* VỀ mixinHost cho chiều mod→mixin; danh sách
     * dưới đây định tuyến các package "hook/compat" NÀY vào bukkitLoader cho chiều ngược lại
     * (NMS/Paper code gọi vào modloader).
     *
     * <p>CHỈ liệt kê PACKAGE, không phải class — mọi class con (kể cả inner class, kể cả class
     * thêm sau này) tự động được include. Không được thêm các package "lõi" của modloader
     * (internal, mixin, event, ModLoaderCore, ...) vào đây — những package đó PHẢI tiếp tục do
     * riêng {@code MixinAwareClassLoader} sở hữu (xem header-comment file này để hiểu vì sao trộn
     * 2 bản của cùng 1 class = LinkageError/IllegalAccessError).
     */
    private static final String[] PACKAGE_PREFIXES_TO_EXPOSE = {
            "ankhangbo/modloader/asm/FabricLifecycleHooks",       // giữ nguyên: 1 class cụ thể (entrypoint gọi từ NMS)
            "ankhangbo/modloader/asm/TransformerAPI",             // + TransformerAPI$SafeTransformer — cũng cụ thể, KHÔNG expose cả package asm/
            "ankhangbo/modloader/compat/fabricnet/",
            "ankhangbo/modloader/compat/fabricregistry/",
            "ankhangbo/modloader/compat/fabricloader/",           // <-- gồm cả SimpleVersion.class, tự động, không cần nhớ liệt kê
            "ankhangbo/modloader/compat/fabriccommand/",
            "ankhangbo/modloader/compat/fabriclifecycle/",
            "ankhangbo/modloader/compat/fabriccreativetab/",
            "ankhangbo/modloader/fabricjar/",                     // FabricModLoader, FabricModContainer, FabricModMetadata, semver/*
            "ankhangbo/modloader/tweaker/",
            "net/fabricmc/",                                      // toàn bộ shaded fabric-api + loader-api surface
    };

    /**
     * TỪNG loại trừ {@code net.fabricmc.loader.api.Version} ở đây với lý do "nó tự resolve được
     * qua parent-delegation bình thường" — GIẢ ĐỊNH ĐÓ SAI, đã gây crash thật:
     * {@code NoClassDefFoundError: net/fabricmc/loader/api/Version} ngay tại
     * {@code FabricLoaderImpl.getAllMods()} (gọi từ Paper's SystemReport khi crash). Paper hoàn
     * toàn không biết gì về Fabric — {@code bukkitLoader}'s parent chain (JVM system classloader)
     * KHÔNG có {@code Version} ở bất kỳ đâu, nên "parent-delegation bình thường" không có gì để
     * tìm thấy cả.
     *
     * <p>Không loại trừ gì nữa: mọi class {@code FabricLoaderImpl}/{@code SimpleVersion} cần đều
     * được đưa vào CÙNG 1 minimal hooks jar, tức CÙNG 1 classloader identity — không có nguy cơ
     * "2 bản khác nhau của cùng 1 class" ở đây, vì cả 2 phía (interface Version và implementation
     * SimpleVersion) đều được định nghĩa bởi chính bridge này, không phải bởi 2 loader khác nhau.
     * Rủi ro "IncompatibleClassChangeError" mà comment cũ lo chỉ xảy ra nếu có 1 THIRD PARTY (mod
     * thật, load qua ModClassLoader/mixinHost) cũng độc lập implement/dùng {@code Version} VÀ
     * tương tác trực tiếp với object {@code FabricLoaderImpl} trả về — nhưng {@code FabricLoaderImpl}
     * ở đây chỉ tồn tại để phục vụ {@code SystemReport} của Paper (liệt kê mod khi crash), object
     * của nó không bao giờ chảy sang phía mod thật, nên an toàn.
     */
    private static final Set<String> EXCLUDE_EVEN_IF_PREFIX_MATCHES = Set.of();



    private ClassLoaderBridge() {}

    /**
     * Opens java.base's java.net package to our own module, so the {@code addURL} reflection
     * below doesn't throw {@code InaccessibleObjectException} on Java 9+. Safe to call from
     * multiple places — only does the actual work once.
     */
    static synchronized void init(java.lang.instrument.Instrumentation inst) {
        if (moduleOpened) return;
        try {
            java.lang.Module javaBase = Object.class.getModule();
            java.lang.Module ourModule = ClassLoaderBridge.class.getModule();
            inst.redefineModule(
                    javaBase,
                    Collections.emptySet(),
                    Collections.emptyMap(),
                    java.util.Map.of("java.net", java.util.Set.of(ourModule)),
                    Collections.emptySet(),
                    Collections.emptyMap());
            moduleOpened = true;
            LOGGER.info("Opened java.base/java.net to our module (for ClassLoaderBridge's addURL reflection)");
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to self-open java.base/java.net — addURL reflection below will fail "
                    + "with InaccessibleObjectException; add --add-opens java.base/java.net=ALL-UNNAMED to the "
                    + "java command line as a workaround", t);
        }
    }

    /**
     * Public so {@code ModLoaderHooks.init()} can call this EAGERLY, once, the moment
     * {@code bukkitLoader} first becomes available — instead of only reactively, lazily, the
     * first time some ASM transformer's {@code transform()} happens to fire (the previous-only
     * call path, still used by every {@code *AsmTransformer} for defense-in-depth in case this
     * eager call somehow didn't run first). Calling it as early as possible means the hook/compat
     * classes are visible to bukkitLoader before almost anything could need them, instead of
     * discovering gaps reactively one crash at a time (exactly how the {@code SimpleVersion} and
     * {@code Version} crashes above were found — a single eager, complete exposure closes that
     * whole class of bug at once instead of one class at a time).
     */
    public static void ensureHooksVisible(ClassLoader targetLoader) {
        if (targetLoader == null) return; // bootstrap classloader already sees everything on -Xbootclasspath/a
        if (targetLoader == ClassLoaderBridge.class.getClassLoader()) return; // same loader as us already — nothing to do
        if (!PATCHED_LOADERS.add(targetLoader)) return; // already handled this exact loader instance

        if (!(targetLoader instanceof URLClassLoader urlLoader)) {
            LOGGER.warning("Target classloader " + targetLoader.getClass().getName() + " is not a URLClassLoader — "
                    + "cannot append a jar to it. Injected fabric lifecycle hooks calling into "
                    + "ankhangbo.modloader.asm.FabricLifecycleHooks will throw NoClassDefFoundError from this loader.");
            return;
        }

        try {
            File minimalJar = buildMinimalHooksJar();
            Method addUrl = URLClassLoader.class.getDeclaredMethod("addURL", URL.class);
            addUrl.setAccessible(true);
            addUrl.invoke(urlLoader, minimalJar.toURI().toURL());
            LOGGER.info("Made hook/compat packages (" + String.join(", ", PACKAGE_PREFIXES_TO_EXPOSE)
                    + " — via " + minimalJar + ") visible to " + targetLoader
                    + " — injected fabric lifecycle hook calls will now resolve from that loader.");
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to make FabricLifecycleHooks visible to target classloader " + targetLoader
                    + " — injected fabric lifecycle hooks will throw NoClassDefFoundError at runtime from this loader", t);
        }
    }

    /**
     * Adds a REAL mod jar's URL directly onto {@code bukkitLoader} (or whatever loader is passed
     * in — always {@code bukkitLoader} in practice, never {@code realClassLoader}/mixinHost, which
     * already see every mod jar through the normal ModClassLoader chain).
     *
     * <p>WHY THIS EXISTS — this is the fix for "server → mods: NoClassDefFoundError" affecting
     * basically every mod that uses Mixin's accessor/interface-injection pattern
     * (e.g. {@code @Mixin(Target.class) interface TargetAccessor extends Target}): when Mixin
     * weaves {@code implements TargetAccessor} onto a vanilla class, that vanilla class is DEFINED
     * by {@code bukkitLoader} — so the JVM has to resolve {@code TargetAccessor} using
     * {@code bukkitLoader} itself, at class-definition time. {@code TargetAccessor} normally only
     * exists inside that mod's own {@code ModClassLoader}, a CHILD of {@code bukkitLoader} — and
     * a parent can never see a child's classes, no matter how the call got there. This is the
     * exact inverse of {@link #ensureHooksVisible}'s problem (that one is about OUR OWN hook
     * classes; this one is about every third-party mod's accessor/interface classes), so it reuses
     * the identical addURL-via-reflection mechanism.
     *
     * <p>Trade-off, deliberately accepted: adding a mod's full jar URL to {@code bukkitLoader}
     * means {@code bukkitLoader} can now WIN the parent-first delegation race to define that mod's
     * classes itself (instead of the mod's own {@code ModClassLoader}), the same way it already
     * can for {@code net/fabricmc/}. That merges every such mod's classes into the same shared
     * "server-visible" namespace — matching how a real unified Fabric/Forge classloader treats
     * game+mods as one classpath. It does mean two different mod jars that both declare the exact
     * same class name will collide once both are exposed here (rare in practice; every real
     * modloader that supports Mixin accessor injection has this same constraint). This does NOT
     * affect per-mod {@code ModClassLoader} isolation for anything that never gets resolved
     * through {@code bukkitLoader} in the first place (i.e. normal, non-Mixin-injected code).
     *
     * <p>Safe to call more than once for the same (loader, jar) pair — deduplicated via
     * {@link #EXPOSED_JARS}, keyed by loader identity + absolute jar path (unlike
     * {@link #ensureHooksVisible}, which only ever needs to run once per loader, this runs once
     * PER MOD JAR against the same {@code bukkitLoader}).
     */
    public static void exposeJarToBukkit(File jarFile, ClassLoader bukkitLoader) {
        if (bukkitLoader == null || jarFile == null) return;
        String dedupeKey = System.identityHashCode(bukkitLoader) + "|" + jarFile.getAbsolutePath();
        if (!EXPOSED_JARS.add(dedupeKey)) return; // already exposed this exact jar to this exact loader

        if (!(bukkitLoader instanceof URLClassLoader urlLoader)) {
            LOGGER.warning("bukkitLoader " + bukkitLoader.getClass().getName() + " is not a URLClassLoader — "
                    + "cannot append " + jarFile.getName() + " to it. Mixin accessor/interface classes "
                    + "from this mod that get woven onto vanilla classes will throw NoClassDefFoundError "
                    + "the moment that vanilla class loads.");
            return;
        }

        try {
            Method addUrl = URLClassLoader.class.getDeclaredMethod("addURL", URL.class);
            addUrl.setAccessible(true);
            addUrl.invoke(urlLoader, jarFile.toURI().toURL());
            LOGGER.info("Exposed mod jar " + jarFile.getName() + " directly to bukkitLoader (" + bukkitLoader
                    + ") — Mixin-injected accessor/interface classes from this mod, woven onto vanilla "
                    + "classes, can now resolve.");
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to expose mod jar " + jarFile.getName() + " to bukkitLoader — "
                    + "any Mixin accessor/interface this mod weaves onto a vanilla class will throw "
                    + "NoClassDefFoundError the moment that vanilla class loads", t);
        }
    }

    /**
     * Builds a throwaway jar containing every class under {@link #PACKAGE_PREFIXES_TO_EXPOSE}
     * (minus {@link #EXCLUDE_EVEN_IF_PREFIX_MATCHES}), found by actually scanning our own agent
     * jar's entries — NOT a hardcoded list, so a brand new class dropped into any of those
     * packages is automatically included next run, no code change needed here. Reads bytes
     * straight from the jar entry (never a class literal / Class.forName) so nothing here forces
     * any of these classes to be loaded by OUR classloader first — see the identical caution in
     * ModLoaderAgent.exposeHooksToBootstrap for why that matters.
     */
    private static File buildMinimalHooksJar() throws IOException {
        File tempJar = File.createTempFile("modloader-fabric-hooks", ".jar");
        tempJar.deleteOnExit();

        File agentJarFile = locateOwnJarFile();
        int included = 0;
        try (JarFile agentJar = new JarFile(agentJarFile);
             JarOutputStream jos = new JarOutputStream(new FileOutputStream(tempJar))) {
            var entries = agentJar.entries();
            while (entries.hasMoreElements()) {
                JarEntry entry = entries.nextElement();
                String name = entry.getName();
                if (entry.isDirectory() || !name.endsWith(".class")) continue;
                if (!matchesExposedPrefix(name) || EXCLUDE_EVEN_IF_PREFIX_MATCHES.contains(name)) continue;

                try (InputStream in = agentJar.getInputStream(entry)) {
                    jos.putNextEntry(new JarEntry(name));
                    in.transferTo(jos);
                    jos.closeEntry();
                }
                included++;
            }
        }

        if (included == 0) {
            LOGGER.warning("buildMinimalHooksJar() included 0 classes — PACKAGE_PREFIXES_TO_EXPOSE may not match "
                    + "anything in " + agentJarFile + ", or locateOwnJarFile() found the wrong file. Every injected "
                    + "hook call will throw NoClassDefFoundError.");
        } else {
            final int includedFinal = included;
            LOGGER.fine(() -> "buildMinimalHooksJar() included " + includedFinal + " classes from " + agentJarFile);
        }
        return tempJar;
    }

    private static boolean matchesExposedPrefix(String internalClassName) {
        for (String prefix : PACKAGE_PREFIXES_TO_EXPOSE) {
            if (internalClassName.startsWith(prefix)) return true;
        }
        return false;
    }

    /**
     * Finds the actual jar file this class was loaded from, so {@link #buildMinimalHooksJar()}
     * can scan its real entry list. Falls back to walking a directory of loose .class files
     * (exploded classes — e.g. running straight from an IDE's output dir instead of a built jar)
     * if the code source isn't a jar.
     */
    private static File locateOwnJarFile() throws IOException {
        try {
            URL location = ClassLoaderBridge.class.getProtectionDomain().getCodeSource().getLocation();
            File file = new File(location.toURI());
            if (file.isFile()) return file;
            if (file.isDirectory()) return packDirectoryAsTempJar(file);
            throw new IOException("Code source " + file + " is neither a file nor a directory");
        } catch (Exception e) {
            throw new IOException("Could not locate the jar/classes this agent was loaded from — "
                    + "buildMinimalHooksJar() cannot scan for classes to expose", e);
        }
    }

    /** Dev/IDE fallback: pack an exploded classes/ directory into a temp jar so JarFile scanning works uniformly. */
    private static File packDirectoryAsTempJar(File classesDir) throws IOException {
        File tempJar = File.createTempFile("modloader-agent-classes", ".jar");
        tempJar.deleteOnExit();
        java.nio.file.Path root = classesDir.toPath();
        try (JarOutputStream jos = new JarOutputStream(new FileOutputStream(tempJar))) {
            try (var walk = java.nio.file.Files.walk(root)) {
                for (java.nio.file.Path path : (Iterable<java.nio.file.Path>) walk.filter(java.nio.file.Files::isRegularFile)::iterator) {
                    String entryName = root.relativize(path).toString().replace(File.separatorChar, '/');
                    jos.putNextEntry(new JarEntry(entryName));
                    java.nio.file.Files.copy(path, jos);
                    jos.closeEntry();
                }
            }
        }
        return tempJar;
    }
}
