package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;

/**
 * Strips {@code ACC_FINAL} from the two static fields fabric-registry-sync-v0 needs to mutate at
 * runtime (to let mods register new dynamic/synced registries after these lists have already been
 * initialised):
 * <ul>
 *   <li>{@code net.minecraft.resources.RegistryDataLoader#SYNCHRONIZED_REGISTRIES} — public but
 *       final on this Paper build.</li>
 *   <li>{@code net.minecraft.core.RegistrySynchronization#NETWORKABLE_REGISTRIES} — private AND
 *       final; the private part is fine (plain reflection + {@code setAccessible(true)} handles
 *       that), it's the final part the JVM verifier won't allow around without this.</li>
 * </ul>
 * Same technique as {@link DebugLevelSourceAsmTransformer} — see its javadoc for why a plain
 * {@code @Mutable}-style ACC_FINAL strip is needed instead of just reflection. Actually reading/
 * writing these fields afterward is done via plain reflection in
 * {@link ankhangbo.modloader.compat.fabricregistry.RegistrySyncAccessors}.
 */
public class DynamicRegistriesAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String REGISTRY_DATA_LOADER = "net/minecraft/resources/RegistryDataLoader";
    private static final String REGISTRY_SYNCHRONIZATION = "net/minecraft/core/RegistrySynchronization";

    private static final Map<String, String> TARGET_FIELDS = Map.of(
            REGISTRY_DATA_LOADER, "SYNCHRONIZED_REGISTRIES",
            REGISTRY_SYNCHRONIZATION, "NETWORKABLE_REGISTRIES"
    );

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        String targetField = TARGET_FIELDS.get(className);
        if (targetField == null) return null;

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            boolean patched = false;
            for (FieldNode fn : cn.fields) {
                if (fn.name.equals(targetField) && (fn.access & Opcodes.ACC_FINAL) != 0) {
                    fn.access &= ~Opcodes.ACC_FINAL;
                    patched = true;
                    break;
                }
            }

            if (!patched) {
                LOGGER.warning(className + ": " + targetField + " not found as a final field — "
                        + "either the field name changed on this build, or it's already non-final. "
                        + "RegistrySyncAccessors writes to it will throw if the name actually changed.");
                return null;
            }

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + className + " (stripped ACC_FINAL from " + targetField
                    + " for fabric-registry-sync-v0 dynamic/synced registry registration)");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + className + " — leaving class unmodified", t);
            return null;
        }
    }
}
