package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.ListIterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Replaces the real fabric-api {@code CreativeModeTabAccessor} + {@code CreativeModeTabMixin} on
 * {@code net.minecraft.world.item.CreativeModeTab}, in three parts:
 * <ol>
 *   <li>Strips {@code ACC_FINAL} from the {@code row}/{@code column} fields (both {@code private
 *       final}), so {@code ankhangbo.modloader.compat.fabriccreativetab.CreativeTabAccessors}'
 *       reflective setters work — same technique as {@code DynamicRegistriesAsmTransformer}.</li>
 *   <li>Adds a REAL {@code FabricCreativeModeTabImpl} interface implementation
 *       ({@code fabric_getPage()}/{@code fabric_setPage(int)}), delegating to the side table in
 *       {@code CreativeTabHooks} — same technique as {@code PacketContextProviderAsmTransformer}.</li>
 *   <li>Tail-injects a call to {@code CreativeTabHooks.onBuildContents(this, parameters)} at every
 *       {@code RETURN} in {@code buildContents(ItemDisplayParameters)} — same technique as
 *       {@code WorldTickTransformer}.</li>
 * </ol>
 */
public class CreativeModeTabAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String TARGET_CLASS = "net/minecraft/world/item/CreativeModeTab";
    private static final String PARAMS_DESC = "Lnet/minecraft/world/item/CreativeModeTab$ItemDisplayParameters;";
    private static final String IFACE = "net/fabricmc/fabric/impl/creativetab/FabricCreativeModeTabImpl";
    private static final String HOOKS = "ankhangbo/modloader/compat/fabriccreativetab/CreativeTabHooks";

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET_CLASS.equals(className)) return null;

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            if (cn.interfaces.contains(IFACE)) return null; // already patched

            // 1. Strip ACC_FINAL from row/column.
            int finalsStripped = 0;
            for (FieldNode fn : cn.fields) {
                if ((fn.name.equals("row") || fn.name.equals("column")) && (fn.access & Opcodes.ACC_FINAL) != 0) {
                    fn.access &= ~Opcodes.ACC_FINAL;
                    finalsStripped++;
                }
            }
            if (finalsStripped != 2) {
                LOGGER.warning(TARGET_CLASS + ": expected to strip ACC_FINAL from 2 fields (row, column), "
                        + "actually stripped " + finalsStripped + " — did this Paper build rename/change them? "
                        + "CreativeTabAccessors.setRow/setColumn will throw if the fields are still final.");
            }

            // 2. Real FabricCreativeModeTabImpl implementation.
            cn.interfaces.add(IFACE);
            cn.methods.add(fabricGetPageMethod());
            cn.methods.add(fabricSetPageMethod());

            // 3. Tail-inject into buildContents(ItemDisplayParameters).
            boolean patchedBuildContents = false;
            for (MethodNode mn : cn.methods) {
                if (!mn.name.equals("buildContents") || !mn.desc.equals("(" + PARAMS_DESC + ")V")) continue;

                ListIterator<AbstractInsnNode> it = mn.instructions.iterator();
                while (it.hasNext()) {
                    AbstractInsnNode insn = it.next();
                    if (insn.getOpcode() == Opcodes.RETURN) {
                        InsnList before = new InsnList();
                        before.add(new VarInsnNode(Opcodes.ALOAD, 0));
                        before.add(new VarInsnNode(Opcodes.ALOAD, 1));
                        before.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "onBuildContents",
                                "(L" + TARGET_CLASS + ";" + PARAMS_DESC + ")V", false));
                        mn.instructions.insertBefore(insn, before);
                    }
                }
                patchedBuildContents = true;
            }
            if (!patchedBuildContents) {
                LOGGER.warning(TARGET_CLASS + ": did not find buildContents(ItemDisplayParameters) — "
                        + "CreativeModeTabEvents.MODIFY_OUTPUT/MODIFY_OUTPUT_ALL will never fire. "
                        + "Your Paper build may have renamed/changed this method.");
            }

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + TARGET_CLASS + " (ACC_FINAL strip on row/column, FabricCreativeModeTabImpl, "
                    + "buildContents hook)");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + TARGET_CLASS + " — leaving class unmodified. "
                    + "fabric-creative-tab-api-v1 will not work at all for this class.", t);
            return null;
        }
    }

    /** {@code public int fabric_getPage() { return CreativeTabHooks.fabricGetPage(this); }} */
    private MethodNode fabricGetPageMethod() {
        MethodNode mn = new MethodNode(Opcodes.ACC_PUBLIC, "fabric_getPage", "()I", null, null);
        mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
        mn.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "fabricGetPage",
                "(L" + TARGET_CLASS + ";)I", false));
        mn.instructions.add(new InsnNode(Opcodes.IRETURN));
        return mn;
    }

    /** {@code public void fabric_setPage(int page) { CreativeTabHooks.fabricSetPage(this, page); }} */
    private MethodNode fabricSetPageMethod() {
        MethodNode mn = new MethodNode(Opcodes.ACC_PUBLIC, "fabric_setPage", "(I)V", null, null);
        mn.instructions.add(new VarInsnNode(Opcodes.ALOAD, 0));
        mn.instructions.add(new VarInsnNode(Opcodes.ILOAD, 1));
        mn.instructions.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "fabricSetPage",
                "(L" + TARGET_CLASS + ";I)V", false));
        mn.instructions.add(new InsnNode(Opcodes.RETURN));
        return mn;
    }
}
