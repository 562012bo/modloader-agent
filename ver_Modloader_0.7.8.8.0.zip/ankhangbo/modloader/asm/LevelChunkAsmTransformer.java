package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Replaces {@code LevelChunkMixin} — three hooks, all of which read only values that are already
 * the receiver/arguments of the exact instruction being patched, so none of this needs debug info.
 */
public class LevelChunkAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String TARGET = "net/minecraft/world/level/chunk/LevelChunk";
    private static final String HOOKS = "ankhangbo/modloader/asm/FabricLifecycleHooks";
    private static final String CHUNK_DESC = "Lnet/minecraft/world/level/chunk/LevelChunk;";
    private static final String BE_DESC = "Lnet/minecraft/world/level/block/entity/BlockEntity;";

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET.equals(className)) return null;
        ClassLoaderBridge.ensureHooksVisible(loader);

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            for (MethodNode mn : cn.methods) {
                switch (mn.name) {
                    case "setBlockEntity" -> patchSetBlockEntity(mn);
                    case "getBlockEntity" -> patchGetBlockEntity(mn);
                    case "removeBlockEntity" -> patchRemoveBlockEntity(mn);
                    default -> { }
                }
            }

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + TARGET + " with fabric BLOCK_ENTITY_LOAD/UNLOAD hooks (LevelChunkMixin replacement)");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + className + " — leaving class unmodified", t);
            return null;
        }
    }

    /**
     * onLoadBlockEntity (@ModifyExpressionValue on Map.put) + onRemoveBlockEntity#1 (@Inject
     * AFTER BlockEntity.setRemoved()). Both live in setBlockEntity(BlockEntity).
     */
    private void patchSetBlockEntity(MethodNode mn) {
        if (!mn.desc.equals("(" + BE_DESC + ")V")) return;

        for (AbstractInsnNode insn : mn.instructions.toArray()) {
            if (insn instanceof MethodInsnNode min && min.getOpcode() == Opcodes.INVOKEINTERFACE
                    && min.owner.equals("java/util/Map") && min.name.equals("put")
                    && min.desc.equals("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) {
                // Stack after (unmodified) call: [result]. blockEntity is the method's own param (slot 1).
                InsnList after = new InsnList();
                after.add(new InsnNode(Opcodes.DUP));
                after.add(new TypeInsnNode(Opcodes.CHECKCAST, "net/minecraft/world/level/block/entity/BlockEntity"));
                after.add(new VarInsnNode(Opcodes.ALOAD, 1)); // blockEntity param
                after.add(new VarInsnNode(Opcodes.ALOAD, 0)); // this (chunk)
                after.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "blockEntityLoad",
                        "(" + BE_DESC + BE_DESC + CHUNK_DESC + ")V", false));
                mn.instructions.insert(min, after);
            } else if (insn instanceof MethodInsnNode min && min.getOpcode() == Opcodes.INVOKEVIRTUAL
                    && min.owner.equals("net/minecraft/world/level/block/entity/BlockEntity")
                    && min.name.equals("setRemoved") && min.desc.equals("()V")) {
                // Capture the receiver (previousEntry), fire the hook AFTER the call (matches shift=AFTER).
                InsnList before = new InsnList();
                before.add(new InsnNode(Opcodes.DUP));
                mn.instructions.insertBefore(min, before);

                InsnList after = new InsnList();
                after.add(new VarInsnNode(Opcodes.ALOAD, 0)); // this (chunk)
                after.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "blockEntityUnload",
                        "(" + BE_DESC + CHUNK_DESC + ")V", false));
                mn.instructions.insert(min, after);
            }
        }
    }

    /** onRemoveBlockEntity (@Redirect on Map.remove(Object)) inside getBlockEntity(BlockPos, EntityCreationType). */
    private void patchGetBlockEntity(MethodNode mn) {
        if (!mn.desc.equals("(Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/chunk/LevelChunk$EntityCreationType;)" + BE_DESC)) {
            return;
        }

        for (AbstractInsnNode insn : mn.instructions.toArray()) {
            if (!(insn instanceof MethodInsnNode min)) continue;
            if (min.getOpcode() != Opcodes.INVOKEINTERFACE || !min.owner.equals("java/util/Map")
                    || !min.name.equals("remove") || !min.desc.equals("(Ljava/lang/Object;)Ljava/lang/Object;")) continue;

            // Fully replace this call: stack before is [map, key] -> push "this" and call our helper instead.
            InsnList replacement = new InsnList();
            replacement.add(new VarInsnNode(Opcodes.ALOAD, 0));
            replacement.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "redirectedMapRemove",
                    "(Ljava/util/Map;Ljava/lang/Object;" + CHUNK_DESC + ")Ljava/lang/Object;", false));
            mn.instructions.insertBefore(min, replacement);
            mn.instructions.remove(min);
            break; // the @Slice in the original mixin restricts this to one call site anyway
        }
    }

    /** onRemoveBlockEntity#2 (@Inject BEFORE BlockEntity.setRemoved()) inside removeBlockEntity(BlockPos). */
    private void patchRemoveBlockEntity(MethodNode mn) {
        if (!mn.desc.equals("(Lnet/minecraft/core/BlockPos;)V")) return;

        for (AbstractInsnNode insn : mn.instructions.toArray()) {
            if (insn instanceof MethodInsnNode min && min.getOpcode() == Opcodes.INVOKEVIRTUAL
                    && min.owner.equals("net/minecraft/world/level/block/entity/BlockEntity")
                    && min.name.equals("setRemoved") && min.desc.equals("()V")) {
                InsnList before = new InsnList();
                before.add(new InsnNode(Opcodes.DUP));
                before.add(new VarInsnNode(Opcodes.ALOAD, 0)); // this (chunk)
                before.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "blockEntityUnload",
                        "(" + BE_DESC + CHUNK_DESC + ")V", false));
                mn.instructions.insertBefore(min, before);
            }
        }
    }
}
