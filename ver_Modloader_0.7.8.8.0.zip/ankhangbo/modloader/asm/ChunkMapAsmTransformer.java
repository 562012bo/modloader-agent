package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Replaces {@code ChunkMapMixin}: fires {@code ServerChunkEvents.CHUNK_UNLOAD} when a chunk is
 * actually unloaded.
 *
 * v4 — ROOT CAUSE FOUND: on this Paper build (Moonrise chunk-system patches),
 * {@code net.minecraft.server.level.ChunkMap#save(ChunkAccess)} is a dead stub:
 *
 *     public boolean save(ChunkAccess chunk) {
 *         throw new UnsupportedOperationException();
 *     }
 *
 * It is never called from anywhere — v3's whole approach (scan for an invokevirtual call to
 * that method, in either ChunkMap or ChunkHolderManager) can never succeed on this build, which
 * is exactly what the diagnostic dump proved: neither class contains such a call.
 *
 * The real, single choke point where a chunk is unloaded (saved + detached from the world) is
 * {@code ca.spottedleaf.moonrise.patches.chunk_system.scheduling.NewChunkHolder#unloadStage2
 * (NewChunkHolder.UnloadState)}. It is called exactly once, from
 * {@code ChunkHolderManager#processUnloads()}, and it receives the {@code ChunkAccess} directly
 * via {@code state.chunk()}. The holder itself exposes the level as the field
 * {@code public final ServerLevel world}.
 *
 * So instead of hunting for a specific method call inside the method body (which doesn't exist),
 * this transformer inserts code at the very START of {@code unloadStage2}, using only the
 * method's own parameter and the holder's own field:
 *
 *   ChunkAccess chunk = state.chunk();
 *   if (chunk != null) FabricLifecycleHooks.chunkUnload(this.world, chunk);
 *   // ... original method body follows unchanged ...
 */
public class ChunkMapAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String NEW_CHUNK_HOLDER = "ca/spottedleaf/moonrise/patches/chunk_system/scheduling/NewChunkHolder";
    private static final String UNLOAD_STATE = "ca/spottedleaf/moonrise/patches/chunk_system/scheduling/NewChunkHolder$UnloadState";
    private static final String HOOKS = "ankhangbo/modloader/asm/FabricLifecycleHooks";
    private static final String SERVER_LEVEL_DESC = "Lnet/minecraft/server/level/ServerLevel;";
    private static final String CHUNK_ACCESS_DESC = "Lnet/minecraft/world/level/chunk/ChunkAccess;";
    private static final String UNLOAD_STAGE2_DESC = "(L" + UNLOAD_STATE + ";)V";

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!NEW_CHUNK_HOLDER.equals(className)) return null;
        ClassLoaderBridge.ensureHooksVisible(loader);

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            String worldFieldName = findServerLevelFieldName(cn);
            if (worldFieldName == null) {
                LOGGER.warning(className + ": could not find a ServerLevel field on NewChunkHolder — CHUNK_UNLOAD cannot fire.");
                return null;
            }

            MethodNode target = null;
            for (MethodNode mn : cn.methods) {
                if (mn.name.equals("unloadStage2") && mn.desc.equals(UNLOAD_STAGE2_DESC)) {
                    target = mn;
                    break;
                }
            }

            if (target == null) {
                LOGGER.warning(className + ": method unloadStage2" + UNLOAD_STAGE2_DESC
                        + " not found — CHUNK_UNLOAD will not fire. Methods in this class: " + describeMethods(cn));
                return null;
            }

            injectUnloadHook(target, worldFieldName);

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + className + " with fabric CHUNK_UNLOAD hook (unloadStage2 entry, world field=" + worldFieldName + ")");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + className + " — leaving class unmodified", t);
            return null;
        }
    }

    private String findServerLevelFieldName(ClassNode cn) {
        for (var f : cn.fields) {
            if (SERVER_LEVEL_DESC.equals(f.desc)) return f.name;
        }
        return null;
    }

    private String describeMethods(ClassNode cn) {
        StringBuilder sb = new StringBuilder();
        for (MethodNode mn : cn.methods) sb.append(mn.name).append(mn.desc).append(", ");
        return sb.toString();
    }

    /**
     * Inserts, as the first instructions of unloadStage2(UnloadState state):
     *
     *   ChunkAccess chunk = state.chunk();
     *   if (chunk != null) {
     *       FabricLifecycleHooks.chunkUnload(this.world, chunk);
     *   }
     *   // original body continues
     */
    private void injectUnloadHook(MethodNode mn, String worldFieldName) {
        int tempChunk = mn.maxLocals;
        mn.maxLocals = tempChunk + 1;

        LabelNode skip = new LabelNode();

        InsnList prelude = new InsnList();
        // state.chunk() -> ChunkAccess
        prelude.add(new VarInsnNode(Opcodes.ALOAD, 1));
        prelude.add(new MethodInsnNode(Opcodes.INVOKEVIRTUAL, UNLOAD_STATE, "chunk", "()" + CHUNK_ACCESS_DESC, false));
        prelude.add(new InsnNode(Opcodes.DUP));
        prelude.add(new VarInsnNode(Opcodes.ASTORE, tempChunk));
        prelude.add(new JumpInsnNode(Opcodes.IFNULL, skip));
        // this.world
        prelude.add(new VarInsnNode(Opcodes.ALOAD, 0));
        prelude.add(new FieldInsnNode(Opcodes.GETFIELD, NEW_CHUNK_HOLDER, worldFieldName, SERVER_LEVEL_DESC));
        prelude.add(new VarInsnNode(Opcodes.ALOAD, tempChunk));
        prelude.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "chunkUnload",
                "(" + SERVER_LEVEL_DESC + CHUNK_ACCESS_DESC + ")V", false));
        prelude.add(skip);

        mn.instructions.insert(prelude);
    }
}