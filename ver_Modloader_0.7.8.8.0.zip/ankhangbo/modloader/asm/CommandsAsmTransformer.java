package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Replaces the real fabric-api {@code CommandsMixin}: injects a call to
 * {@code CommandHooks.onCommandsInit(dispatcher, buildContext, selection)} — which fires
 * {@code CommandRegistrationCallback.EVENT} — right after
 * {@code this.dispatcher.setConsumer(ExecutionCommandSource.resultConsumer())} inside
 * {@code Commands}' 3-arg constructor (the one with a body; the 2-arg constructor just delegates
 * to it via {@code this(...)}). Same injection point the original mixin targeted
 * ({@code @Inject(method = "<init>", at = @At(value = "INVOKE", target = "...setConsumer..."))})
 * — "add commands before ambiguities are calculated", i.e. before the dispatcher is handed off.
 *
 * <p>{@code dispatcher} is a {@code private final} field with an inline initializer
 * ({@code = new CommandDispatcher()}), so by the time our injected code runs (after all the
 * vanilla {@code XyzCommand.register(this.dispatcher, ...)} calls earlier in the constructor
 * body) it's already fully populated — reading {@code this.dispatcher} via a plain
 * {@code GETFIELD} inserted directly into the constructor's own bytecode needs no reflection at
 * all, since the inserted instructions live inside {@code Commands} itself.
 */
public class CommandsAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String TARGET_CLASS = "net/minecraft/commands/Commands";
    private static final String CTOR_DESC = "(Lnet/minecraft/commands/Commands$CommandSelection;Lnet/minecraft/commands/CommandBuildContext;Z)V";
    private static final String DISPATCHER_DESC = "Lcom/mojang/brigadier/CommandDispatcher;";
    private static final String HOOKS = "ankhangbo/modloader/compat/fabriccommand/CommandHooks";

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET_CLASS.equals(className)) return null;

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            boolean patched = false;
            for (MethodNode mn : cn.methods) {
                if (!mn.name.equals("<init>") || !mn.desc.equals(CTOR_DESC)) continue;

                for (AbstractInsnNode insn : mn.instructions.toArray()) {
                    if (insn.getOpcode() != Opcodes.INVOKEVIRTUAL) continue;
                    if (!(insn instanceof MethodInsnNode min)) continue;
                    if (!min.name.equals("setConsumer") || !min.owner.equals("com/mojang/brigadier/CommandDispatcher")) continue;

                    // ALOAD 0 (this) -> GETFIELD dispatcher -> ALOAD 2 (buildContext) -> ALOAD 1 (selection)
                    // -> INVOKESTATIC CommandHooks.onCommandsInit(CommandDispatcher, CommandBuildContext, CommandSelection)
                    InsnList after = new InsnList();
                    after.add(new VarInsnNode(Opcodes.ALOAD, 0));
                    after.add(new FieldInsnNode(Opcodes.GETFIELD, TARGET_CLASS, "dispatcher", DISPATCHER_DESC));
                    after.add(new VarInsnNode(Opcodes.ALOAD, 2));
                    after.add(new VarInsnNode(Opcodes.ALOAD, 1));
                    after.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "onCommandsInit",
                            "(" + DISPATCHER_DESC + "Lnet/minecraft/commands/CommandBuildContext;"
                                    + "Lnet/minecraft/commands/Commands$CommandSelection;)V", false));
                    mn.instructions.insert(insn, after);
                    patched = true;
                    break; // only one setConsumer() call in this constructor
                }
            }

            if (!patched) {
                LOGGER.warning(TARGET_CLASS + ": did not find " + CTOR_DESC + " calling setConsumer(...) — "
                        + "CommandRegistrationCallback.EVENT will never fire. Your Paper build may have changed "
                        + "the Commands constructor shape; update CTOR_DESC in this class.");
                return null;
            }

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + TARGET_CLASS + " to fire CommandRegistrationCallback.EVENT after setConsumer(...)");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + TARGET_CLASS + " — leaving class unmodified. "
                    + "CommandRegistrationCallback.EVENT will never fire.", t);
            return null;
        }
    }
}
