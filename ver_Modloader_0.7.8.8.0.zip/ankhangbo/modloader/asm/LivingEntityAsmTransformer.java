package ankhangbo.modloader.asm;

import java.lang.instrument.ClassFileTransformer;
import java.security.ProtectionDomain;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.TypeInsnNode;
import org.objectweb.asm.tree.VarInsnNode;

/**
 * Replaces {@code LivingEntityMixin}: fires {@code ServerEntityEvents.EQUIPMENT_CHANGE} right
 * after the {@code Map.put(slot, current)} call inside {@code collectEquipmentChanges()}.
 *
 * "slot" and "current" are the put(...) call's own two arguments — captured straight off the
 * stack, no debug info needed. "previous" is NOT one of this call's arguments (it was assigned
 * earlier in the loop from {@code this.lastEquipmentItems.get(equipmentSlot)}), so it is the one
 * value here looked up via {@link LocalVarFinder} against the compiled LocalVariableTable — see
 * that class' javadoc for the caveat this implies. If your build renamed/stripped that local, this
 * hook simply won't fire (guarded to no-op, not to throw — see
 * {@link FabricLifecycleHooks#equipmentChange}).
 *
 * NOTE: the actual local's name in YOUR compiled class might not be "previous" — the fabric-api
 * mixin assumes that name, but variable names can differ between the exact Minecraft/Paper build
 * this was written against and yours (decompiling your own server jar and checking with
 * {@code javap -p -l} is the only way to be certain — see PREVIOUS_NAME_CANDIDATES below for a
 * couple of common alternates to try if the event never fires).
 */
public class LivingEntityAsmTransformer implements ClassFileTransformer {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/ASM");

    private static final String TARGET = "net/minecraft/world/entity/LivingEntity";
    private static final String HOOKS = "ankhangbo/modloader/asm/FabricLifecycleHooks";

    /** Try these in order if "previous" isn't found — adjust/add to match your actual compiled class. */
    private static final String[] PREVIOUS_NAME_CANDIDATES = {"previous", "previousItem", "oldStack"};

    @Override
    public byte[] transform(ClassLoader loader, String className, Class<?> classBeingRedefined,
                             ProtectionDomain protectionDomain, byte[] classfileBuffer) {
        if (!TARGET.equals(className)) return null;
        ClassLoaderBridge.ensureHooksVisible(loader);

        try {
            ClassReader reader = new ClassReader(classfileBuffer);
            ClassNode cn = new ClassNode();
            reader.accept(cn, ClassReader.EXPAND_FRAMES);

            boolean patched = false;
            for (MethodNode mn : cn.methods) {
                if (mn.name.equals("collectEquipmentChanges")) {
                    patched = patchMethod(mn);
                }
            }

            if (!patched) {
                LOGGER.warning("LivingEntity: could not find/patch collectEquipmentChanges() — "
                        + "EQUIPMENT_CHANGE will not fire.");
                return null;
            }

            ClassWriter writer = new SafeClassWriter(ClassWriter.COMPUTE_FRAMES | ClassWriter.COMPUTE_MAXS, loader);
            cn.accept(writer);
            LOGGER.info("Patched " + TARGET + " with fabric EQUIPMENT_CHANGE hook (LivingEntityMixin replacement)");
            return writer.toByteArray();
        } catch (Throwable t) {
            LOGGER.log(Level.SEVERE, "Failed to patch " + className + " — leaving class unmodified", t);
            return null;
        }
    }

    private boolean patchMethod(MethodNode mn) {
        for (AbstractInsnNode insn : mn.instructions.toArray()) {
            if (!(insn instanceof MethodInsnNode min)) continue;
            if (min.getOpcode() != Opcodes.INVOKEINTERFACE) continue;
            if (!min.owner.equals("java/util/Map") || !min.name.equals("put")
                    || !min.desc.equals("(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;")) continue;

            int previousSlot = -1;
            String usedName = null;
            for (String candidate : PREVIOUS_NAME_CANDIDATES) {
                previousSlot = LocalVarFinder.findLocal(mn, min, candidate);
                if (previousSlot != -1) {
                    usedName = candidate;
                    break;
                }
            }
            if (previousSlot == -1) {
                LOGGER.warning("LivingEntity.collectEquipmentChanges(): none of " + java.util.Arrays.toString(PREVIOUS_NAME_CANDIDATES)
                        + " found in the LocalVariableTable at the Map.put(...) call — EQUIPMENT_CHANGE will not fire for this build. "
                        + "Run `javap -p -l -c LivingEntity.class` on your server jar and add the real name to PREVIOUS_NAME_CANDIDATES.");
                continue;
            }
            LOGGER.fine("Using local variable '" + usedName + "' for 'previous' ItemStack");

            int tempCurrent = mn.maxLocals;
            int tempSlot = mn.maxLocals + 1;
            int tempResult = mn.maxLocals + 2;

            // Stack before call: [map, slot, current] (current on top)
            // DUP2_X1: duplicate top TWO values and insert them 3 down
            // before: ..., value3, value2, value1 -> after: ..., value2, value1, value3, value2, value1
            // (value3=map, value2=slot, value1=current)
            InsnList beforeCall = new InsnList();
            beforeCall.add(new InsnNode(Opcodes.DUP2_X1));
            mn.instructions.insertBefore(min, beforeCall);
            // Stack now: [slot_dup, current_dup, map, slot, current] -> original call consumes top 3.

            // After the (unmodified) put call: stack = [slot_dup, current_dup, result]
            InsnList afterCall = new InsnList();
            afterCall.add(new VarInsnNode(Opcodes.ASTORE, tempResult));   // [slot_dup, current_dup]
            afterCall.add(new VarInsnNode(Opcodes.ASTORE, tempCurrent));  // [slot_dup]
            afterCall.add(new VarInsnNode(Opcodes.ASTORE, tempSlot));     // []

            afterCall.add(new VarInsnNode(Opcodes.ALOAD, 0)); // this (LivingEntity)
            afterCall.add(new VarInsnNode(Opcodes.ALOAD, tempSlot));
            afterCall.add(new TypeInsnNode(Opcodes.CHECKCAST, "net/minecraft/world/entity/EquipmentSlot"));
            afterCall.add(new VarInsnNode(Opcodes.ALOAD, previousSlot));
            afterCall.add(new VarInsnNode(Opcodes.ALOAD, tempCurrent));
            afterCall.add(new TypeInsnNode(Opcodes.CHECKCAST, "net/minecraft/world/item/ItemStack"));
            afterCall.add(new MethodInsnNode(Opcodes.INVOKESTATIC, HOOKS, "equipmentChange",
                    "(Lnet/minecraft/world/entity/LivingEntity;Lnet/minecraft/world/entity/EquipmentSlot;"
                            + "Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/item/ItemStack;)V", false));

            afterCall.add(new VarInsnNode(Opcodes.ALOAD, tempResult)); // restore original put() result
            mn.instructions.insert(min, afterCall);

            mn.maxLocals = tempResult + 1;
            return true;
        }
        return false;
    }
}
