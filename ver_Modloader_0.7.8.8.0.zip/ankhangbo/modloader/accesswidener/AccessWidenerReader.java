package ankhangbo.modloader.accesswidener;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Parses the same plain-text {@code .accesswidener} format real fabric-loader uses (v1 and v2,
 * including the {@code transitive-} prefix some mods use in v2 — accepted but treated identically
 * to the non-transitive rule, since this modloader has no concept of "propagate to dependents").
 *
 * <pre>
 * accessWidener v2 named
 * accessible class net/foo/Bar
 * extendable class net/foo/Bar
 * mutable   field net/foo/Bar fieldName Lnet/foo/Baz;
 * accessible field net/foo/Bar fieldName Lnet/foo/Baz;
 * accessible method net/foo/Bar methodName (I)V
 * extendable method net/foo/Bar methodName (I)V
 * # comments and blank lines are ignored
 * </pre>
 *
 * Merges directly into the process-wide {@link AccessWidenerRegistry} — call {@link #read} once
 * per mod, as early as possible (before the target classes could plausibly have loaded), same
 * timing constraint as Mixin configs in {@code ModManager#loadOne}.
 */
public final class AccessWidenerReader {
    private static final Logger LOGGER = Logger.getLogger("ModLoader/AccessWidener");

    /** Both real fabric-loader's own format and Quilt's classTweaker format use the exact same
     *  per-line rule grammar ({@code [transitive-]accessible|extendable|mutable class|field|method
     *  ...}) — classTweaker is a superset that also allows a few extra keywords real accessWidener
     *  doesn't (e.g. {@code denied}, {@code extends} clauses) which this reader does not implement;
     *  those extra lines will log "unknown access type" and be skipped, same as any other
     *  unrecognised line, without aborting the rest of the file. */
    private static final String[] VALID_HEADER_KEYWORDS = { "accessWidener", "classTweaker" };

    private AccessWidenerReader() {}

    /** @return {@code true} if a rule file was actually parsed (even if 0 rules matched anything at
     *  runtime), {@code false} if the header was missing/invalid and nothing was applied — callers
     *  MUST check this before logging a "loaded successfully" message. */
    public static boolean read(String sourceDescription, InputStream in) {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String headerLine = reader.readLine();
            if (headerLine != null && !headerLine.isEmpty() && headerLine.charAt(0) == '\uFEFF') {
                // Strip a UTF-8 BOM some tools/editors prepend — otherwise startsWith(...) below
                // fails even though the rest of the line is a perfectly valid header.
                headerLine = headerLine.substring(1);
            }

            boolean validHeader = false;
            if (headerLine != null) {
                for (String keyword : VALID_HEADER_KEYWORDS) {
                    if (headerLine.startsWith(keyword)) {
                        validHeader = true;
                        break;
                    }
                }
            }
            if (!validHeader) {
                LOGGER.warning(sourceDescription + ": missing/invalid 'accessWidener v1|v2 <namespace>' "
                        + "or 'classTweaker v1|v2 <namespace>' header — skipping");
                return false;
            }
            LOGGER.info(sourceDescription + ": reading (header: '" + headerLine + "')");

            String line;
            int lineNo = 1;
            int rulesParsed = 0;
            while ((line = reader.readLine()) != null) {
                lineNo++;
                if (parseLine(sourceDescription, lineNo, line)) rulesParsed++;
            }
            LOGGER.info(sourceDescription + ": finished — " + rulesParsed + " rule(s) parsed from " + (lineNo - 1) + " line(s)");
            return true;
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Failed to read access widener from " + sourceDescription, e);
            return false;
        }
    }

    private static boolean parseLine(String sourceDescription, int lineNo, String rawLine) {
        int comment = rawLine.indexOf('#');
        String line = (comment >= 0 ? rawLine.substring(0, comment) : rawLine).trim();
        if (line.isEmpty()) return false;

        String[] parts = line.split("\\s+");
        int idx = 0;
        String accessWord = parts[idx++];
        if (accessWord.startsWith("transitive-")) {
            accessWord = accessWord.substring("transitive-".length());
        }

        if (accessWord.equals("inject-interface")) {
            // classTweaker directive: "inject-interface <targetClass> <interfaceToImplement>", both
            // already in internal-name (slash) form, e.g. "net/minecraft/world/level/BlockGetter
            // net/fabricmc/fabric/api/blockgetter/v2/FabricBlockGetter". Registered into
            // AccessWidenerRegistry and applied for real by AccessWidenerAsmTransformer (adds the
            // interface to the target's actual `implements` list via ASM) — safe because Fabric's
            // own convention for inject-interface requires the injected interface to consist
            // entirely of default/static methods, so no method body needs to be generated here,
            // unlike e.g. PacketContextProviderAsmTransformer's hand-written case.
            if (idx + 1 >= parts.length) {
                LOGGER.warning(sourceDescription + ":" + lineNo
                        + ": 'inject-interface' needs <targetClass> <interfaceToImplement> — skipping line: " + line);
                return false;
            }
            String targetClass = parts[idx];
            String ifaceClass = parts[idx + 1];
            AccessWidenerRegistry.addInterfaceInjection(targetClass, ifaceClass);
            return true;
        }

        AccessWidenerRegistry.Access access = switch (accessWord) {
            case "accessible" -> AccessWidenerRegistry.Access.ACCESSIBLE;
            case "extendable" -> AccessWidenerRegistry.Access.EXTENDABLE;
            case "mutable" -> AccessWidenerRegistry.Access.MUTABLE;
            default -> null;
        };
        if (access == null) {
            LOGGER.warning(sourceDescription + ":" + lineNo + ": unknown access type '" + accessWord + "' — skipping line");
            return false;
        }

        if (idx >= parts.length) {
            LOGGER.warning(sourceDescription + ":" + lineNo + ": missing member type — skipping line");
            return false;
        }
        String memberType = parts[idx++];

        try {
            switch (memberType) {
                case "class" -> {
                    String owner = parts[idx];
                    AccessWidenerRegistry.addClassRule(owner, access);
                }
                case "field" -> {
                    String owner = parts[idx++];
                    String name = parts[idx++];
                    String descriptor = parts[idx];
                    AccessWidenerRegistry.addFieldRule(owner, name, descriptor, access);
                }
                case "method" -> {
                    String owner = parts[idx++];
                    String name = parts[idx++];
                    String descriptor = parts[idx];
                    AccessWidenerRegistry.addMethodRule(owner, name, descriptor, access);
                }
                default -> {
                    LOGGER.warning(sourceDescription + ":" + lineNo + ": unknown member type '" + memberType + "' — skipping line");
                    return false;
                }
            }
            return true;
        } catch (ArrayIndexOutOfBoundsException e) {
            LOGGER.warning(sourceDescription + ":" + lineNo + ": malformed line (missing owner/name/descriptor) — skipping: " + rawLine);
            return false;
        }
    }
}
