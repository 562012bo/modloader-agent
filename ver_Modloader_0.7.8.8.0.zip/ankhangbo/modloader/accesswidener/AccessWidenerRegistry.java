package ankhangbo.modloader.accesswidener;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Global, merged view of every mod's {@code .accesswidener} file. Populated by
 * {@link AccessWidenerReader} while mods are being discovered (see
 * {@code ankhangbo.modloader.internal.ModManager#loadOne}), and read from
 * {@code ankhangbo.modloader.asm.AccessWidenerAsmTransformer} as each target class actually loads.
 *
 * <p>Same idea as real fabric-loader's {@code AccessWidener}/{@code AccessWidenerClassVisitor}
 * split, and the same idea as Fabric Loader's later "class tweaker" generalisation of it — see
 * {@link ankhangbo.modloader.tweaker.ClassTweaker} for that side. Kept as its own simpler
 * data-driven system here (rather than folded into class tweakers) because access widening is by
 * far the most common thing a ported mod's build actually needs, and a plain text format any mod
 * author can hand-edit is much friendlier than requiring a compiled {@code ClassTweaker} class for
 * the common case.
 */
public final class AccessWidenerRegistry {

    public enum Access { ACCESSIBLE, EXTENDABLE, MUTABLE }

    /** owner internal name (e.g. {@code net/minecraft/world/entity/Entity}) -> rules for that class. */
    private static final Map<String, ClassRules> RULES = new ConcurrentHashMap<>();

    private AccessWidenerRegistry() {}

    public static ClassRules rulesFor(String ownerInternalName) {
        return RULES.get(ownerInternalName);
    }

    public static boolean hasAnyRulesFor(String ownerInternalName) {
        return RULES.containsKey(ownerInternalName);
    }

    static void addClassRule(String owner, Access access) {
        rules(owner).classAccess.add(access);
    }

    static void addFieldRule(String owner, String name, String descriptor, Access access) {
        rules(owner).fieldAccess.computeIfAbsent(name + descriptor, k -> EnumSet.noneOf(Access.class)).add(access);
    }

    static void addMethodRule(String owner, String name, String descriptor, Access access) {
        rules(owner).methodAccess.computeIfAbsent(name + descriptor, k -> EnumSet.noneOf(Access.class)).add(access);
    }

    /**
     * Registers a classTweaker {@code inject-interface <owner> <iface>} directive: {@code owner}
     * will genuinely {@code implements iface} once loaded (see
     * {@code ankhangbo.modloader.asm.AccessWidenerAsmTransformer}, which adds it to the class's
     * real {@code interfaces} list via ASM). Only safe/meaningful for interfaces whose methods are
     * ALL default (or static) methods — same requirement real fabric-loader's own inject-interface
     * has, since nothing here generates any method body, just the {@code implements} declaration
     * itself; an interface with abstract methods would leave the target class uninstantiable
     * (AbstractMethodError at the first unimplemented call, same as it would be handwritten).
     */
    static void addInterfaceInjection(String owner, String ifaceInternalName) {
        rules(owner).interfacesToInject.add(ifaceInternalName);
    }

    private static ClassRules rules(String owner) {
        return RULES.computeIfAbsent(owner, k -> new ClassRules());
    }

    /**
     * Registers this modloader's own built-in widening rules — the ones core ported fabric-api
     * modules need on vanilla/Paper classes themselves, as opposed to a 3rd-party mod's own
     * {@code .accesswidener} file (see {@link AccessWidenerReader}). Real fabric-api ships its own
     * {@code fabric-api-base.accesswidener}-style files bundled right in each module's jar for
     * exactly this reason — this is the equivalent for this modloader. Call once, early in
     * {@code ModLoaderAgent.premain()}, right after registering {@code AccessWidenerAsmTransformer}
     * and before any of these classes could plausibly have loaded.
     */
    public static void registerBuiltins() {
        // fabric-creative-tab-api-v1: CreativeModeTab.Output/TabVisibility are `protected` nested
        // types, but FabricCreativeModeTabOutput (in a completely different package) implements
        // Output and uses TabVisibility all over its own public API — both need to be public.
        addClassRule("net/minecraft/world/item/CreativeModeTab$Output", Access.ACCESSIBLE);
        addClassRule("net/minecraft/world/item/CreativeModeTab$TabVisibility", Access.ACCESSIBLE);

        // fabric-creative-tab-api-v1: CreativeModeTabsMixin's ported pagination logic
        // (CreativeTabHooks#paginateTabs) reads all 14 of these `private` ResourceKey constants.
        String resourceKeyDesc = "Lnet/minecraft/resources/ResourceKey;";
        String creativeModeTabs = "net/minecraft/world/item/CreativeModeTabs";
        for (String field : new String[] {
                "BUILDING_BLOCKS", "COLORED_BLOCKS", "NATURAL_BLOCKS", "FUNCTIONAL_BLOCKS", "REDSTONE_BLOCKS",
                "HOTBAR", "SEARCH", "TOOLS_AND_UTILITIES", "COMBAT", "FOOD_AND_DRINKS", "INGREDIENTS",
                "SPAWN_EGGS", "OP_BLOCKS", "INVENTORY"
        }) {
            addFieldRule(creativeModeTabs, field, resourceKeyDesc, Access.ACCESSIBLE);
        }

        // --- Rules below come directly from real crash reports where a mod ships a genuine
        // "accessWidener v2 official" rule for these exact members, but this modloader doesn't
        // ship real fabric-loader's own bundled/builtin widener that vanilla fabric-api normally
        // relies on for the same members. Without these, mods that touch these members directly
        // (rather than through a fabric-api wrapper) get IllegalAccessError/IncompatibleClassChangeError. ---

        // Fabric networking mods (e.g. veinminer) read the server off a connected ServerPlayer
        // directly instead of going through a fabric-api accessor:
        //   java.lang.IllegalAccessError: class ... tried to access private field
        //   net.minecraft.server.level.ServerPlayer.server
        addFieldRule("net/minecraft/server/level/ServerPlayer", "server",
                "Lnet/minecraft/server/MinecraftServer;", Access.ACCESSIBLE);

        // fabric-networking-api-v1's own PacketContextProvider/NetworkingHooks plumbing (see
        // ankhangbo.modloader.compat.fabricnet.NetworkingHooks) needs the raw Connection off
        // ServerCommonPacketListenerImpl to build a PacketContext:
        //   java.lang.IllegalAccessError: ... tried to access private field
        //   net.minecraft.server.network.ServerCommonPacketListenerImpl.connection
        addFieldRule("net/minecraft/server/network/ServerCommonPacketListenerImpl", "connection",
                "Lnet/minecraft/network/Connection;", Access.ACCESSIBLE);

        // fabric-object-builder-api-v1's FabricBlockEntityTypeBuilder implements this
        // package-private functional interface from a different package/classloader than
        // BlockEntityType itself, so plain "same package" default access doesn't apply:
        //   java.lang.IllegalAccessError: failed to access class
        //   net.minecraft.world.level.block.entity.BlockEntityType$BlockEntitySupplier
        addClassRule("net/minecraft/world/level/block/entity/BlockEntityType$BlockEntitySupplier", Access.ACCESSIBLE);

        // Several ported mods (e.g. supermartijn642corelib's BaseBlock) override this vanilla
        // method, which is `final` on real Paper/vanilla:
        //   java.lang.IncompatibleClassChangeError: class ... overrides final method
        //   BlockBehaviour.getDescriptionId()Ljava/lang/String;
        addMethodRule("net/minecraft/world/level/block/state/BlockBehaviour", "getDescriptionId",
                "()Ljava/lang/String;", Access.EXTENDABLE);

        // Mods that register custom tag entry types (e.g. supermartijn642corelib's
        // CustomTagEntries) need to replace this static final CODEC:
        //   java.lang.IllegalAccessError: Update to static final field
        //   net.minecraft.tags.TagEntry.CODEC attempted from a different class
        addFieldRule("net/minecraft/tags/TagEntry", "CODEC",
                "Lcom/mojang/serialization/Codec;", Access.MUTABLE);

        // fabric-recipe-api-v1's own CustomIngredientImpl extends this vanilla class directly
        // (real fabric-loader ships this same widening in fabric-api's bundled accesswidener):
        //   java.lang.IncompatibleClassChangeError: class ... cannot inherit from final class
        //   net.minecraft.world.item.crafting.Ingredient
        addClassRule("net/minecraft/world/item/crafting/Ingredient", Access.EXTENDABLE);

        // Several ported mods call this directly instead of going through a fabric-api wrapper:
        //   java.lang.IllegalAccessError: ... tried to access private method
        //   SpawnPlacements.register(EntityType, SpawnPlacementType, Heightmap$Types, SpawnPredicate)
        addMethodRule("net/minecraft/world/entity/SpawnPlacements", "register",
                "(Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/entity/SpawnPlacementType;"
                        + "Lnet/minecraft/world/level/levelgen/Heightmap$Types;"
                        + "Lnet/minecraft/world/entity/SpawnPlacements$SpawnPredicate;)V", Access.ACCESSIBLE);
    }

    public static final class ClassRules {
        public final Set<Access> classAccess = EnumSet.noneOf(Access.class);
        /** key: {@code name + descriptor} */
        public final Map<String, Set<Access>> fieldAccess = new ConcurrentHashMap<>();
        /** key: {@code name + descriptor} */
        public final Map<String, Set<Access>> methodAccess = new ConcurrentHashMap<>();
        /** Internal names of interfaces this class should genuinely {@code implements} once loaded. */
        public final Set<String> interfacesToInject = java.util.concurrent.ConcurrentHashMap.newKeySet();
    }
}