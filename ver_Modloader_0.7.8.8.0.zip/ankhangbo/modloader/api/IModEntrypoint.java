package ankhangbo.modloader.api;

/**
 * Implement this in the class referenced by "mainClass" in mods.json.
 * Every method is optional (default no-op) — a mod can implement 0 to 6 of them,
 * exactly as needed. If "mainClass" is empty in mods.json, the mod is treated as a
 * pure library / Mixin-only mod and no entrypoint instance is created at all.
 *
 * Call order during a normal server boot:
 *
 *   [JVM starts, our premain() runs] -> onInitialize()      (before ANYTHING else, before main())
 *   [org.bukkit.craftbukkit.Main.main() begins execution]   -> onLoadMod()
 *   [each Bukkit plugin's onLoad() is invoked]               -> onLoadPlugins()   (once per plugin, see note)
 *   [each Bukkit plugin's onEnable() is invoked]              -> onEnablePlugins() (once per plugin, see note)
 *   [server shutdown]                                         -> onStop()
 *   [/modreload command]                                      -> onReload()
 *
 * Note on onLoadPlugins/onEnablePlugins: these fire once per plugin that goes through
 * JavaPluginLoader#loadPlugin / #enablePlugin, and receive the plugin name so you can
 * filter to the plugin(s) you actually care about (see ModAPI#getCurrentPluginContext()).
 */
public interface IModEntrypoint {

    /** Runs as early as physically possible: inside premain(), before the server's main() method runs at all. */
    default void onInitialize(ModAPI api) {}

    /** Runs the instant org.bukkit.craftbukkit.Main.main() starts executing. */
    default void onLoadMod(ModAPI api) {}

    /** Runs when a plugin's onLoad() runs (i.e. JavaPluginLoader#loadPlugin). */
    default void onLoadPlugins(ModAPI api, String pluginName) {}

    /** Runs when a plugin's onEnable() runs (i.e. JavaPluginLoader#enablePlugin). */
    default void onEnablePlugins(ModAPI api, String pluginName) {}

    /** Runs on server shutdown (JVM shutdown hook). */
    default void onStop(ModAPI api) {}

    /** Runs when an admin executes /modreload for this mod (or /modreload all). */
    default void onReload(ModAPI api) {}
}
