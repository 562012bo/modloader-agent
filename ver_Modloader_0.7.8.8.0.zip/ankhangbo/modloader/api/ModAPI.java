package ankhangbo.modloader.api;

import ankhangbo.modloader.asm.TransformerAPI;
import ankhangbo.modloader.bridge.PluginBridge;
import ankhangbo.modloader.bukkit.BukkitBridge;
import ankhangbo.modloader.command.CommandRegistry;
import ankhangbo.modloader.command.ModCommands;
import ankhangbo.modloader.config.ConfigManager;
import ankhangbo.modloader.event.EventBus;
import ankhangbo.modloader.hook.HookRegistry;
import ankhangbo.modloader.logger.ModLogger;
import ankhangbo.modloader.network.raw.NetworkManager;
import ankhangbo.modloader.registry.BuiltInRegistries;
import ankhangbo.modloader.registry.DefaultedRegistry;
import ankhangbo.modloader.registry.MappedRegistry;
import ankhangbo.modloader.registry.RegistryKey;
import ankhangbo.modloader.scheduler.Scheduler;

import java.io.File;
import java.lang.instrument.ClassFileTransformer;
import java.util.logging.Logger;

/**
 * Single object handed to every IModEntrypoint hook. This is the "surface" a mod talks to:
 * events, commands, config, registries, low-level networking, ASM transformers, and a
 * logger scoped to your mod.
 *
 * A NOTE ON WHEN THINGS ARE SAFE TO USE — this matters more here than in most APIs, because
 * this loader's whole reason for existing is running code BEFORE org.bukkit.craftbukkit.Main
 * itself has started:
 *   - events(), config(), registry(), and the shared NetworkManager are pure JDK/Netty/Gson —
 *     zero Bukkit/Paper dependency, safe from onInitialize() onward (the very first hook,
 *     before Main() runs at all).
 *   - commands() and bukkit() are NOT safe until onEnablePlugins(api, "ModLoaderCompanion") —
 *     both need a real Bukkit Plugin object that doesn't exist any earlier, exactly like
 *     registering a command or an event listener from a normal Bukkit plugin would require
 *     being past onEnable(). Calling either earlier throws NullPointerException, not silently
 *     no-ops.
 *
 *     NOTE: because the SAME ModAPI instance is reused across every hook for a given mod
 *     (see ModLoaderCore#apiFor), commandRegistry/bukkitBridge are deliberately mutable here,
 *     not captured once at construction — a mod that implements both onInitialize() (which
 *     runs long before the bridge plugin exists) and onEnablePlugins() (which runs after) gets
 *     the SAME api object in both, and it only becomes usable for commands()/bukkit() once
 *     ModLoaderCore#attachBridgePlugin has actually run — see that method for how already-cached
 *     ModAPI instances get updated in place.
 */
public class ModAPI {

    private final String modId;
    private final EventBus eventBus;
    private volatile CommandRegistry commandRegistry;
    private volatile BukkitBridge bukkitBridge;
    private volatile Scheduler scheduler;
    private volatile HookRegistry hooks;
    private volatile PluginBridge pluginBridge;
    private final NetworkManager networkManager;
    private final ConfigManager configManager;
    private final File modsDir;
    private final java.util.Map<ankhangbo.modloader.config.ConfigFormat, ConfigManager> altConfigManagers = new java.util.concurrent.ConcurrentHashMap<>();
    private final Logger logger;
    private final ModLogger modLogger;
    private volatile String currentPluginContext; // set right before onLoadPlugins/onEnablePlugins fires
    private volatile ankhangbo.modloader.data.PersistentData persistentData;
    private final ankhangbo.modloader.data.Serialization serialization = new ankhangbo.modloader.data.Serialization();
    private volatile ankhangbo.modloader.world.WorldApi worldApi;
    private volatile ankhangbo.modloader.ui.UiApi uiApi;

    public ModAPI(String modId, EventBus eventBus, CommandRegistry commandRegistry, BukkitBridge bukkitBridge,
                  Scheduler scheduler, NetworkManager networkManager, File modsDir) {
        this.modId = modId;
        this.eventBus = eventBus;
        this.commandRegistry = commandRegistry;
        this.bukkitBridge = bukkitBridge;
        this.scheduler = scheduler;
        this.hooks = bukkitBridge != null ? new HookRegistry(bukkitBridge, eventBus) : null;
        this.pluginBridge = bukkitBridge != null ? new PluginBridge() : null;
        this.persistentData = bukkitBridge != null ? new ankhangbo.modloader.data.PersistentData(bukkitBridge.plugin(), modId) : null;
        this.worldApi = bukkitBridge != null ? new ankhangbo.modloader.world.WorldApi(bukkitBridge) : null;
        this.uiApi = bukkitBridge != null ? new ankhangbo.modloader.ui.UiApi(bukkitBridge) : null;
        this.networkManager = networkManager;
        this.configManager = new ConfigManager(modsDir, modId);
        this.modsDir = modsDir;
        this.logger = Logger.getLogger("Mod/" + modId);
        this.modLogger = new ModLogger(modId, this.logger, configManager);
    }

    public EventBus events() {
        return eventBus;
    }

    /** Safe from onEnablePlugins(api, "ModLoaderCompanion") onward only — see class javadoc. */
    public ModCommands commands() {
        return new ModCommands(commandRegistry, modId);
    }

    /**
     * Generic hook into any Bukkit/Paper event class — see {@link BukkitBridge}'s own javadoc.
     * Safe from onEnablePlugins(api, "ModLoaderCompanion") onward only — see class javadoc.
     */
    public BukkitBridge bukkit() {
        return bukkitBridge;
    }

    /** Called once from ModLoaderCore#attachBridgePlugin — see this class' javadoc note above. */
    public void updateBridgeAccess(CommandRegistry commandRegistry, BukkitBridge bukkitBridge, Scheduler scheduler) {
        this.commandRegistry = commandRegistry;
        this.bukkitBridge = bukkitBridge;
        this.scheduler = scheduler;
        this.hooks = new HookRegistry(bukkitBridge, eventBus);
        this.pluginBridge = new PluginBridge();
        this.persistentData = new ankhangbo.modloader.data.PersistentData(bukkitBridge.plugin(), modId);
        this.worldApi = new ankhangbo.modloader.world.WorldApi(bukkitBridge);
        this.uiApi = new ankhangbo.modloader.ui.UiApi(bukkitBridge);
    }

    /**
     * Bukkit-scheduler wrapper (runTask/runLater/runRepeating, plus async variants) — see
     * {@link Scheduler}'s own javadoc. Safe from onEnablePlugins(api, "ModLoaderCompanion")
     * onward only, same timing as {@link #commands()}/{@link #bukkit()}.
     */
    public Scheduler scheduler() {
        return scheduler;
    }

    /**
     * Namespaced {@link org.bukkit.persistence.PersistentDataContainer} convenience wrapper —
     * see {@link ankhangbo.modloader.data.PersistentData}'s own javadoc. Real public API, zero
     * reflection. Same timing restriction as {@link #bukkit()} (needs a real bridge Plugin).
     */
    public ankhangbo.modloader.data.PersistentData persistentData() {
        return persistentData;
    }

    /** Generic POJO ↔ JSON helper, usable from onInitialize() onward — see {@link ankhangbo.modloader.data.Serialization}. */
    public ankhangbo.modloader.data.Serialization serialization() {
        return serialization;
    }

    /**
     * Opens a real vanilla plugin-message channel (Minecraft's actual client↔server custom
     * payload protocol) named {@code channelName} — see
     * {@link ankhangbo.modloader.network.PluginMessageChannel}'s own javadoc. Same timing
     * restriction as {@link #bukkit()}.
     */
    public ankhangbo.modloader.network.PluginMessageChannel openChannel(String channelName) {
        return new ankhangbo.modloader.network.PluginMessageChannel(bukkitBridge.plugin(), channelName);
    }

    /** Opens an {@link ankhangbo.modloader.network.Rpc} request/response layer over a plugin-message channel. Same timing restriction as {@link #bukkit()}. */
    public ankhangbo.modloader.network.Rpc openRpc(String channelName) {
        return new ankhangbo.modloader.network.Rpc(bukkitBridge.plugin(), channelName);
    }

    /**
     * Forge-style typed message channel — register message types with
     * {@code SimpleChannel#registerMessage(...)}, send with {@code SimpleChannel#send(...)}. See
     * {@link ankhangbo.modloader.network.ChannelBuilder} and {@link ankhangbo.modloader.network.SimpleChannel}'s
     * own javadocs. Same timing restriction as {@link #bukkit()} (needs the real bridge plugin).
     */
    public ankhangbo.modloader.network.ChannelBuilder channelBuilder(String channelName) {
        return ankhangbo.modloader.network.ChannelBuilder.named(bukkitBridge.plugin(), channelName);
    }

    /** Loot tables, ore generation, tree growth, villager trades — see {@link ankhangbo.modloader.world.WorldApi}. */
    public ankhangbo.modloader.world.WorldApi worldGen() {
        return worldApi;
    }

    /** Menus, boss bars, scoreboards, advancements/toasts — see {@link ankhangbo.modloader.ui.UiApi}. */
    public ankhangbo.modloader.ui.UiApi ui() {
        return uiApi;
    }

    /** Builds a data-driven custom item — see {@link ankhangbo.modloader.item.CustomItem}. Safe from onEnablePlugins() onward (needs {@link #persistentData()}). */
    public ankhangbo.modloader.item.CustomItem newItem(String path, org.bukkit.Material baseMaterial) {
        return new ankhangbo.modloader.item.CustomItem(persistentData, modId, path, baseMaterial);
    }

    /** Builds a data-driven custom mob template — see {@link ankhangbo.modloader.entity.CustomMobBehavior}. Same timing as {@link #newItem}. */
    public ankhangbo.modloader.entity.CustomMobBehavior newMob(String path, org.bukkit.entity.EntityType baseType) {
        return new ankhangbo.modloader.entity.CustomMobBehavior(persistentData, modId, path, baseType);
    }

    /** Real-world/portal helper for custom dimensions — see {@link ankhangbo.modloader.dimension.PortalLinker}. Same timing as {@link #bukkit()}. */
    public ankhangbo.modloader.dimension.PortalLinker portals() {
        return new ankhangbo.modloader.dimension.PortalLinker(bukkitBridge);
    }

    /**
     * Simplified, game-domain-specific event hooks (attack, block break/place, chat, inventory,
     * fishing, explosion, ...) built on top of {@link #bukkit()} — see {@link HookRegistry}.
     * Same timing restriction as {@link #bukkit()}.
     */
    public HookRegistry hooks() {
        return hooks;
    }

    /** Interop with other plugins (WorldEdit, Vault, ...) — see {@link PluginBridge}. Same timing as {@link #bukkit()}. */
    public PluginBridge plugins() {
        return pluginBridge;
    }

    /**
     * Per-mod logger with a toggleable debug channel — {@code debug(...)} messages only print
     * when this mod's config has {@code "debug": true} (see {@link ModLogger}). Prefer this over
     * the plain {@link #logger()} for anything you'd want silence-by-default in production.
     */
    public ModLogger log() {
        return modLogger;
    }

    /** Your mod's own {@code <mods>/config/<modId>.json} file. Safe from onInitialize() onward. */
    public ConfigManager config() {
        return configManager;
    }

    /**
     * Same as {@link #config()} but backed by {@code <modId>.yml} or {@code <modId>.toml}
     * instead of JSON — pick whichever syntax you'd rather hand-edit; the {@link ConfigFile}
     * dot-path API is identical either way. Lazily created and cached per format, so repeated
     * calls with the same format return the same instance (same as {@link #config()} always has).
     */
    public ConfigManager configAs(ankhangbo.modloader.config.ConfigFormat format) {
        if (format == ankhangbo.modloader.config.ConfigFormat.JSON) return configManager;
        return altConfigManagers.computeIfAbsent(format, f -> new ConfigManager(modsDir, modId, f));
    }

    /**
     * The shared, real Netty packet server every mod using this loader talks through (its
     * own port, its own framing — see NetworkManager's javadoc for why). Call
     * {@code network().start(port)} once (idempotent) before registering packets/handlers.
     */
    public NetworkManager network() {
        return networkManager;
    }

    /** Gets (or creates) the shared mod-defined registry for {@code key} — see Registry's javadoc for scope. */
    public <T> MappedRegistry<T> registry(RegistryKey key, Class<T> type) {
        return BuiltInRegistries.get(key, type);
    }

    /** Same as {@link #registry(RegistryKey, Class)} but with a fallback default entry for unknown ids. */
    public <T> DefaultedRegistry<T> registryDefaulted(RegistryKey key, Class<T> type, String defaultId) {
        return BuiltInRegistries.getDefaulted(key, type, defaultId);
    }

    public Logger logger() {
        return logger;
    }

    /**
     * Registers your own ASM ClassFileTransformer, run for every class loaded from this
     * point on. Exceptions your transformer throws are caught and logged — they never crash
     * class loading for the rest of the server. For structural game-logic changes, prefer
     * Mixin (mods.json "mixin" field) instead — see the mod-writing guide, section 6.
     */
    public void registerClassTransformer(ClassFileTransformer transformer) {
        TransformerAPI.register(modId, transformer);
    }

    /**
     * Convenience wrapper over {@link #registerClassTransformer} for the common case of a simple
     * {@code (className, bytes) -> bytes} tweak — see {@link ankhangbo.modloader.tweaker.ClassTweaker}'s
     * javadoc. For no-code access widening (the more common Fabric-mod-porting case), prefer an
     * {@code .accesswidener} file (mods.json {@code "accessWidener"} field) instead.
     */
    public void registerClassTweaker(ankhangbo.modloader.tweaker.ClassTweaker tweaker) {
        TransformerAPI.register(modId, new ankhangbo.modloader.tweaker.ClassTweakerAdapter(tweaker));
    }

    public String modId() {
        return modId;
    }

    /** During onLoadPlugins/onEnablePlugins, tells you which plugin just triggered the hook. */
    public String getCurrentPluginContext() {
        return currentPluginContext;
    }

    public void setCurrentPluginContext(String pluginName) {
        this.currentPluginContext = pluginName;
    }
}
