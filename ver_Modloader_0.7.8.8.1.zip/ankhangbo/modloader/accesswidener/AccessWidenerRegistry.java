package ankhangbo.modloader.accesswidener;

import java.util.EnumSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Global, merged view of every mod's {@code .accesswidener} file. Populated by
 * {@link AccessWidenerReader} while mods are being discovered (see
 * {@code ankhangbo.modloader.internal.ModManager#loadOne}), and read from
 * {@code ankhangbo.modloader.asm.AccessWidenerAsmTransformer} as each target class actually loads.
 *
 * V2 — FIXED CROSS-CLASSLOADER SPLIT-STATE BUG: this class' OWN static fields used to hold the
 * real data directly. But this class gets defined by DIFFERENT classloaders depending on who
 * references it first — AccessWidenerAsmTransformer (registered in premain(), defined via
 * mixinHostClassLoader/system classloader) vs AccessWidenerReader/FabricModLoader (defined via
 * realClassLoader) — meaning there used to be TWO completely independent copies of this class'
 * static state, and a rule registered through one was invisible to the other. Confirmed by real
 * crash logs: every rule that came from a mod's own .accesswidener/.classtweaker file (read via
 * realClassLoader) silently never applied, while this modloader's own registerBuiltins() entries
 * (called directly from premain(), i.e. via mixinHostClassLoader) DID apply — same shape of bug,
 * different symptom, than the Mixin-bootstrap split-identity issue this whole project already
 * went through surgery for earlier.
 *
 * Fix: the actual data now lives on {@code ModLoaderHooks.ACCESS_WIDENER_CLASS_RULES} — see that
 * field's own javadoc for why hosting it there (bootstrap-classloader-exposed) guarantees exactly
 * one copy regardless of which classloader's code is running. This class is now a thin, stateless
 * API wrapper around that shared map — every method converts between this class' own
 * ClassRules/Access types (used locally by callers) and the shared map's plain java.util
 * representation (String/Map/Set only) on every call, so no project-specific object with a
 * split-identity risk ever crosses the classloader boundary.
 */
public final class AccessWidenerRegistry {

    public enum Access { ACCESSIBLE, EXTENDABLE, MUTABLE }

    private AccessWidenerRegistry() {}

    private static Map<String, Object> sharedEntryFor(String owner) {
        return ankhangbo.modloader.ModLoaderHooks.ACCESS_WIDENER_CLASS_RULES.computeIfAbsent(owner, k -> {
            Map<String, Object> entry = new ConcurrentHashMap<>();
            entry.put("classAccess", ConcurrentHashMap.newKeySet());
            entry.put("fieldAccess", new ConcurrentHashMap<String, Set<String>>());
            entry.put("methodAccess", new ConcurrentHashMap<String, Set<String>>());
            entry.put("interfacesToInject", ConcurrentHashMap.newKeySet());
            return entry;
        });
    }

    @SuppressWarnings("unchecked")
    public static ClassRules rulesFor(String ownerInternalName) {
        Map<String, Object> shared = ankhangbo.modloader.ModLoaderHooks.ACCESS_WIDENER_CLASS_RULES.get(ownerInternalName);
        if (shared == null) return new ClassRules();

        ClassRules local = new ClassRules();
        for (String s : (Set<String>) shared.get("classAccess")) {
            local.classAccess.add(Access.valueOf(s));
        }
        for (Map.Entry<String, Set<String>> e : ((Map<String, Set<String>>) shared.get("fieldAccess")).entrySet()) {
            Set<Access> accessSet = EnumSet.noneOf(Access.class);
            for (String s : e.getValue()) accessSet.add(Access.valueOf(s));
            local.fieldAccess.put(e.getKey(), accessSet);
        }
        for (Map.Entry<String, Set<String>> e : ((Map<String, Set<String>>) shared.get("methodAccess")).entrySet()) {
            Set<Access> accessSet = EnumSet.noneOf(Access.class);
            for (String s : e.getValue()) accessSet.add(Access.valueOf(s));
            local.methodAccess.put(e.getKey(), accessSet);
        }
        local.interfacesToInject.addAll((Set<String>) shared.get("interfacesToInject"));
        return local;
    }

    public static boolean hasAnyRulesFor(String ownerInternalName) {
        return ankhangbo.modloader.ModLoaderHooks.ACCESS_WIDENER_CLASS_RULES.containsKey(ownerInternalName);
    }

    @SuppressWarnings("unchecked")
    static void addClassRule(String owner, Access access) {
        ((Set<String>) sharedEntryFor(owner).get("classAccess")).add(access.name());
    }

    @SuppressWarnings("unchecked")
    static void addFieldRule(String owner, String name, String descriptor, Access access) {
        Map<String, Set<String>> fieldAccess = (Map<String, Set<String>>) sharedEntryFor(owner).get("fieldAccess");
        fieldAccess.computeIfAbsent(name + descriptor, k -> ConcurrentHashMap.newKeySet()).add(access.name());
    }

    @SuppressWarnings("unchecked")
    static void addMethodRule(String owner, String name, String descriptor, Access access) {
        Map<String, Set<String>> methodAccess = (Map<String, Set<String>>) sharedEntryFor(owner).get("methodAccess");
        methodAccess.computeIfAbsent(name + descriptor, k -> ConcurrentHashMap.newKeySet()).add(access.name());
    }

    /**
     * Registers a classTweaker {@code inject-interface <owner> <iface>} directive: {@code owner}
     * will genuinely {@code implements iface} once loaded (see
     * {@code ankhangbo.modloader.asm.AccessWidenerAsmTransformer}, which adds it to the class's
     * real {@code interfaces} list via ASM). Only safe/meaningful for interfaces whose methods are
     * ALL default (or static) methods — same requirement real fabric-loader's own inject-interface
     * has, since nothing here generates any method body, just the {@code implements} declaration
     * itself; an interface with abstract methods would leave the target class uninstantiable
     * (AbstractMethodError at the first unimplemented call, same as it would be handwritten).
     */
    @SuppressWarnings("unchecked")
    static void addInterfaceInjection(String owner, String ifaceInternalName) {
        ((Set<String>) sharedEntryFor(owner).get("interfacesToInject")).add(ifaceInternalName);
    }

    /**
     * Registers this modloader's own built-in widening rules — the ones core ported fabric-api
     * modules need on vanilla/Paper classes themselves, as opposed to a 3rd-party mod's own
     * {@code .accesswidener} file (see {@link AccessWidenerReader}). Real fabric-api ships its own
     * {@code fabric-api-base.accesswidener}-style files bundled right in each module's jar for
     * exactly this reason — this is the equivalent for this modloader. Call once, early in
     * {@code ModLoaderAgent.premain()}, right after registering {@code AccessWidenerAsmTransformer}
     * and before any of these classes could plausibly have loaded.
     */
    public static void registerBuiltins() {
        // fabric-creative-tab-api-v1: CreativeModeTab.Output/TabVisibility are `protected` nested
        // types, but FabricCreativeModeTabOutput (in a completely different package) implements
        // Output and uses TabVisibility all over its own public API — both need to be public.
        addClassRule("net/minecraft/world/item/CreativeModeTab$Output", Access.ACCESSIBLE);
        addClassRule("net/minecraft/world/item/CreativeModeTab$TabVisibility", Access.ACCESSIBLE);

        // fabric-creative-tab-api-v1: CreativeModeTabsMixin's ported pagination logic
        // (CreativeTabHooks#paginateTabs) reads all 14 of these `private` ResourceKey constants.
        String resourceKeyDesc = "Lnet/minecraft/resources/ResourceKey;";
        String creativeModeTabs = "net/minecraft/world/item/CreativeModeTabs";
        for (String field : new String[] {
                "BUILDING_BLOCKS", "COLORED_BLOCKS", "NATURAL_BLOCKS", "FUNCTIONAL_BLOCKS", "REDSTONE_BLOCKS",
                "HOTBAR", "SEARCH", "TOOLS_AND_UTILITIES", "COMBAT", "FOOD_AND_DRINKS", "INGREDIENTS",
                "SPAWN_EGGS", "OP_BLOCKS", "INVENTORY"
        }) {
            addFieldRule(creativeModeTabs, field, resourceKeyDesc, Access.ACCESSIBLE);
        }

        // --- Rules below come directly from real crash reports where a mod ships a genuine
        // "accessWidener v2 official" rule for these exact members, but this modloader doesn't
        // ship real fabric-loader's own bundled/builtin widener that vanilla fabric-api normally
        // relies on for the same members. Without these, mods that touch these members directly
        // (rather than through a fabric-api wrapper) get IllegalAccessError/IncompatibleClassChangeError. ---

        // Fabric networking mods (e.g. veinminer) read the server off a connected ServerPlayer
        // directly instead of going through a fabric-api accessor:
        //   java.lang.IllegalAccessError: class ... tried to access private field
        //   net.minecraft.server.level.ServerPlayer.server
        addFieldRule("net/minecraft/server/level/ServerPlayer", "server",
                "Lnet/minecraft/server/MinecraftServer;", Access.ACCESSIBLE);

        // fabric-networking-api-v1's own PacketContextProvider/NetworkingHooks plumbing (see
        // ankhangbo.modloader.compat.fabricnet.NetworkingHooks) needs the raw Connection off
        // ServerCommonPacketListenerImpl to build a PacketContext:
        //   java.lang.IllegalAccessError: ... tried to access private field
        //   net.minecraft.server.network.ServerCommonPacketListenerImpl.connection
        addFieldRule("net/minecraft/server/network/ServerCommonPacketListenerImpl", "connection",
                "Lnet/minecraft/network/Connection;", Access.ACCESSIBLE);

        // fabric-object-builder-api-v1's FabricBlockEntityTypeBuilder implements this
        // package-private functional interface from a different package/classloader than
        // BlockEntityType itself, so plain "same package" default access doesn't apply:
        //   java.lang.IllegalAccessError: failed to access class
        //   net.minecraft.world.level.block.entity.BlockEntityType$BlockEntitySupplier
        addClassRule("net/minecraft/world/level/block/entity/BlockEntityType$BlockEntitySupplier", Access.ACCESSIBLE);

        // Several ported mods (e.g. supermartijn642corelib's BaseBlock) override this vanilla
        // method, which is `final` on real Paper/vanilla:
        //   java.lang.IncompatibleClassChangeError: class ... overrides final method
        //   BlockBehaviour.getDescriptionId()Ljava/lang/String;
        addMethodRule("net/minecraft/world/level/block/state/BlockBehaviour", "getDescriptionId",
                "()Ljava/lang/String;", Access.EXTENDABLE);

        // Mods that register custom tag entry types (e.g. supermartijn642corelib's
        // CustomTagEntries) need to replace this static final CODEC:
        //   java.lang.IllegalAccessError: Update to static final field
        //   net.minecraft.tags.TagEntry.CODEC attempted from a different class
        addFieldRule("net/minecraft/tags/TagEntry", "CODEC",
                "Lcom/mojang/serialization/Codec;", Access.MUTABLE);

        // fabric-recipe-api-v1's own CustomIngredientImpl extends this vanilla class directly
        // (real fabric-loader ships this same widening in fabric-api's bundled accesswidener):
        //   java.lang.IncompatibleClassChangeError: class ... cannot inherit from final class
        //   net.minecraft.world.item.crafting.Ingredient
        addClassRule("net/minecraft/world/item/crafting/Ingredient", Access.EXTENDABLE);

        // Several ported mods call this directly instead of going through a fabric-api wrapper:
        //   java.lang.IllegalAccessError: ... tried to access private method
        //   SpawnPlacements.register(EntityType, SpawnPlacementType, Heightmap$Types, SpawnPredicate)
        addMethodRule("net/minecraft/world/entity/SpawnPlacements", "register",
                "(Lnet/minecraft/world/entity/EntityType;Lnet/minecraft/world/entity/SpawnPlacementType;"
                        + "Lnet/minecraft/world/level/levelgen/Heightmap$Types;"
                        + "Lnet/minecraft/world/entity/SpawnPlacements$SpawnPredicate;)V", Access.ACCESSIBLE);
    }

    public static final class ClassRules {
        public final Set<Access> classAccess = EnumSet.noneOf(Access.class);
        /** key: {@code name + descriptor} */
        public final Map<String, Set<Access>> fieldAccess = new ConcurrentHashMap<>();
        /** key: {@code name + descriptor} */
        public final Map<String, Set<Access>> methodAccess = new ConcurrentHashMap<>();
        /** Internal names of interfaces this class should genuinely {@code implements} once loaded. */
        public final Set<String> interfacesToInject = ConcurrentHashMap.newKeySet();
    }
}
